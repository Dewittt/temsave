var year = new Date().getFullYear();
var day = new Date().getDate();
var month = new Date().getMonth() + 1;

console.log(year + " " + day + " " + month);

laydate.render({
  elem: "#test-n3",
  // format: "MM.dd", //自定义日期显示样式
  showBottom: false,
  value:localStorage.getItem("starttime")==null?
    year +
    "-" +
    (month < 10 ? "0" + month : month) +
    "-" +
    (day < 10 ? "0" + day : day):localStorage.getItem("starttime"),
  done: function(value, date, endDate) {
    localStorage.setItem("starttime",value)
    // console.log(value); //得到日期生成的值，如：2017-08-18
    // console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
    // console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
  }
});
laydate.render({
  elem: "#test-n4",
  // format: "MM.dd", //自定义日期显示样式
  showBottom: false,
  value:localStorage.getItem("endtime")==null?
    year +
    "-" +
    (month < 10 ? "0" + month : month) +
    "-" +
    (day < 10 ? "0" + day : day):localStorage.getItem("endtime"), //设置默认时间
  done: function(value, date, endDate) {
    localStorage.setItem("endtime",value)
    // console.log(value); //得到日期生成的值，如：2017-08-18
    // console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
    // console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
  }
});

$(function() {
  $("#period").change(function() {
    if ($("#period").val() == "其他") {
      $(".dateInput").removeAttr("disabled");
    } else {
      $(".dateInput").attr("disabled", true);
    }
  });
});
