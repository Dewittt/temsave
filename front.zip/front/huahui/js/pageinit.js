$(document).ready(function() {
  var role = getCookie("role");
  var userid = getCookie("userid");
  var username = getCookie("username");
  var userid = getCookie("userid");

  //渲染用户名，id和时候显示切换店铺按钮
  $("#username").text(username);
  $("#userid").text("ID: " + userid);
  if (role == "shop") {
    $("#changeshopbtn").hide();
  }
  if (role == "staff") {
    $("#changeshopbtn").hide();
  }

  //如果是staff，填充input
  if (
    role == "staff" &&
    (window.location.href.indexOf("beauticiantable") >= 0 ||
      window.location.href.indexOf("beautician") >= 0 ||
      window.location.href.indexOf("consultant") >= 0)
  ) {
    $("#staffname").val(username);
    $("#staffname").hide();
  }

  //填充起止时间
  var starttime = localStorage.getItem("starttime");
  if (starttime != null) {
    $("#test-n3").val(starttime);
  }

  var endtime = localStorage.getItem("endtime");
  if (endtime != null) {
    $("#test-n4").val(endtime);
  }

  if (window.history && window.history.pushState) {
    $(window).on('popstate', function () {
      window.history.pushState('forward', null, '#');
      window.history.forward(1); });
  }

  //退出
  $("#out").click(function () {
    Ajax.post(
        {
          url: `wxout`,
        },
        res => {
            Ajax.post(
                {
                  url: `logout`,
                },
                res => {
                  if (res.code===0){
                    window.location.href="./wxredirect";
                  }
                  else {
                    alert("退出失败");
                  }
                }
            );
        }
    );
  });

});
