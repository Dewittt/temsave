function querydata(starttime, endtime, issum) {
    var starttime = $("#test-n3").val();
    var endtime = $("#test-n4").val();
    var period = $("#period").val();


    if (issum == true) {
        period = '时间选择';
        starttime = sessionStorage.getItem("starttime");
        endtime = sessionStorage.getItem("endtime");
    }

    var shopid = parseInt(getCookie("userid"));

    var url = null;
    var data = null;
    var tablename=null;

    //如果是经营分析
    if (window.location.href.indexOf('management') > 0) {
        tablename="经营分析表"
        url = `m/management`
        data = {
            shopid: shopid,
            starttime: starttime,
            endtime: endtime,
            period: period
        }
        //如果是顾问分析
    } else if (window.location.href.indexOf('consultant') > 0) {
        tablename="顾问分析表"
        url = `m/consultant`
        var staffname = $("#staffname").val();
        var shopid = parseInt(getCookie("userid"));
        data = {
            consultantname: staffname,
            shopid: shopid,
            starttime: starttime,
            endtime: endtime,
            period: period
        }
        //如果是顾问分析
    } else if (window.location.href.indexOf('beautician') > 0) {
        tablename="美容师分析表"

        url = `m/beautician`

        var staffname = $("#staffname").val();
        var shopid = parseInt(getCookie("userid"));

        data = {
            beauticianname: staffname,
            shopid: shopid,
            starttime: starttime,
            endtime: endtime,
            period: period
        }
    }

    Ajax.get(
        {
            url: url,
            data: data
        },
        res => {
            console.log(res);
            if (res.code == 0) {
                setstarttimemin(res.data.date.starttime);
                setendtimemax(res.data.date.endtime);
                renderdata(res.data, res.data.date.starttime, res.data.date.endtime, issum,tablename);
            } else {
                alert(res.msg);
            }
        }
    );
}

function renderdata(res, starttime, endtime, issum,tablename) {
    var managementanalysis = res.managementanalysis;
    var tablefooter = res.tablefooter;

    //清除原有数据
    for (let i = 0; i < $(".dataline").length; i++) {
        // $($(".dataline")[i]).empty()
    }

    var thead = $(`
                    <table class="title">
                        <thead>
                            <tr> <td colspan="4" class="xiangqingdate">${issum == true ? '总计' : ''} ${starttime} - ${endtime}</td></tr>
                        </thead>
                        <thead class="biaotou one">
                            <tr>
                                <th rowspan="2" class="tablehead">${tablename}</th>
                            </tr>
                            <tr class="tablebot">
                                <th id="money">金额</th>
                                <th id="num">数量</th>
                            </tr>
                        </thead>
                    </table>`)

    var table = $(`<table class="xiangqing">   </table>`);


    // table.append(`<thead><tr> <td colspan="4" class="xiangqingdate">${starttime} - ${endtime}</td></tr></thead>`)

    var footer = null;


    for (let i = 0; i < managementanalysis.length; i++) {
        var type = managementanalysis[i].type;//实操，产品....
        var t = $(`<thead class="shicao dataline">
                        </thead>`)
        var con = managementanalysis[i].con;//type的数据arr

        for (let j = 0; j < con.length; j++) {
            var temp = con[j];
            var tr = $(`<tr>
                                <th rowspan="${j == 0 ? con.length : ''}" style="${j != 0 ? 'display:none' : ''}" class="${i % 2 == 0 ? 'shicao' : 'chanpin'}">${type}</th>
                                <td class="${temp.category2 == '总计' ? 'zongji' : 'mingcheng'}">${temp.category2}</td>
                                <td class="${temp.category2 == '总计' ? 'zongji' : 'money'}">${temp.summoney}</td>
                                <td class="${temp.category2 == '总计' ? 'zongji' : 'num'}">${temp.sumcount}</td>
                            </tr>`)//一行

            t.append(tr)
        }
        table.append(t)

        footer = $(`
                    <table class="keliu">
                        <thead class="biaotou">
                            <tr>
                                <th class="tablehead" rowspan="2">人头及客流</th>
                                <th colspan="1" class="people one">人头</th>
                                <th colspan="1" class="customer">客流</th>
                            </tr>
                            <tr class="tablebot">
                                <th class="customer one" >${tablefooter.averageprice}</th>
                                <th class="customer" >${tablefooter.headcount}</th>
                            </tr>
                        </thead>
                    </table>
                    <table class="danjia">
                        <tr>
                            <th>平均客单价</th>
                            <th class="price" >${tablefooter.humantraffic}</th>
                        </tr>
                    </table>

                    <div style="height: 20px;"></div>

                `)

    }
    var xiangqing = $(`<div></div>`)

    if (issum == true) {
        xiangqing = $(`<div id="sumtable"></div>`)
    }
    xiangqing.append(thead)
    xiangqing.append(table)
    xiangqing.append(footer)

    if (issum == true) {
        $("#xiangqingcontainer").append(xiangqing);
    }else {
        $("#xiangqingcontainer").prepend(xiangqing);
    }

    if (!issum == true) {
        $("#sumtable").remove()
        querydata(sessionStorage.getItem("starttime"), sessionStorage.getItem("endtime"), true)
    }

}
