window.wxopenid = "wx8839a51596bd5689";
window.redirecturl = "https://hh.zhixingonline.com/m/wxredirect";
