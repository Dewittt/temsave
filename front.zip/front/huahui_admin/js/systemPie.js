var myChart = echarts.init(document.getElementById("main"));
option = {
  title: {
    text: "",
    subtext: "",
    x: "center"
  },
  tooltip: {
    trigger: "item",
    formatter: "{b}"
  },
  series: [
    {
      name: "",
      type: "pie", //饼状图
      radius: "60%", //大小
      center: ["50%", "40%"], //显示位置
      data: [
        {
          value: piedata[0]["con"],
          name: "到店1次",
          itemStyle: { normal: { color: "#E35406" } }
        },
        {
          value: piedata[1]["con"],
          name: "到店2次",
          itemStyle: { normal: { color: "#06E3E0" } }
        },
        {
          value: piedata[2]["con"],
          name: "到店3次",
          itemStyle: { normal: { color: "#E38806" } }
        },
        {
          value: piedata[3]["con"],
          name: "到店4次",
          itemStyle: { normal: { color: "#0698E3" } }
        },
        {
          value: piedata[4]["con"],
          name: "到店5次",
          itemStyle: { normal: { color: "#7306E3" } }
        }
      ], //数据,我们ajax获取
      itemStyle: {
        normal: {
          label: {
            show: true,
            position: "outer",
            fontSize: 14,
            // fontWeight: "bold",
            // align: "left",
            formatter: function(p) {
              //指示线对应文字，说明文字
              return p.data.name;
            }
          },
          color: function(params) {
            //自定义颜色
            var colorList = ["#00CD00", "#FF7F00"];
            return colorList[params.dataIndex];
          },
          labelLine: {
            //指示线状态
            show: true,
            smooth: 0.2,
            length: 10,
            length2: 20
          }
        }
      }
    },
    {
      name: "",
      type: "pie",
      avoidLabelOverlap: true,
      radius: "60%", //大小
      center: ["50%", "40%"], //显示位置
      data: [
        {
          value: piedata[0]["con"],
          name: piedata[0]["百分比"],
          itemStyle: { normal: { color: "#E35406" } }
        },
        {
          value: piedata[1]["con"],
          name: piedata[1]["百分比"],
          itemStyle: { normal: { color: "#06E3E0" } }
        },
        {
          value: piedata[2]["con"],
          name: piedata[2]["百分比"],
          itemStyle: { normal: { color: "#E38806" } }
        },

        {
          value: piedata[3]["con"],
          name: piedata[3]["百分比"],
          itemStyle: { normal: { color: "#0698E3" } }
        },
        {
          value: piedata[4]["con"],
          name: piedata[4]["百分比"],
          itemStyle: { normal: { color: "#7306E3" } }
        }
      ],
      itemStyle: {
        normal: {
          label: {
            show: true,
            position: "inner",
            fontSize: 14,
            // fontWeight: "bold",
            // align: "left",
            formatter: function(p) {
              //指示线对应文字,百分比
              // return p.percent + "%";
              return p.data.name;
            }
          },
          color: function(params) {
            //自定义颜色
            var colorList = ["#00CD00", "#FF7F00"];
            return colorList[params.dataIndex];
          },
          labelLine: {
            //指示线状态
            show: true,
            smooth: 0.2,
            length: 10,
            length2: 20
          }
        }
      }
    }
  ]
};
myChart.setOption(option);
