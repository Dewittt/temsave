function cardCategory(){
    var cardType = $("#cardType").val();
    if (cardType === "现金卡"){
        $("#cash").css("display","block");
        $("#kakou").css("display","none");
    } else{
        // $("#cash").css("display","none");
        // $("#kakou").css("display","block");
        $("#openCardMask").css("display","none");
        $("#huiyuanorder").click()
        window.fromcreatekakoucard=true;
    }
}

function cardConsumption(){
    var consumeInfo = [["现金卡", "卡扣卡"],
        ["现金实操", "卡扣实操", "赠送实操"], ["现金产品", "卡扣产品", "赠送产品"]];
    $("#cardConsumption").empty();
    var category = $("#kakoucategory").val();
    var selectParam;
    var object = $("#cardConsumption");
    if (category === "卡") {
        selectParam = consumeInfo[0];
    } else if (category === "美容" || category === "美体" || category === "仪器") {
        selectParam = consumeInfo[1];
    } else if (category ==="产品") {
        selectParam = consumeInfo[2];
    }else {
        selectParam = null;
    }
    for (var i = 0; i < selectParam.length; i++) {
        object.append(new Option(selectParam[i], selectParam[i]));
    }
}

$(document).ready(function () {

    //渲染会员列表

    function getcard(pagenum,nameortel){
        $("#clubList").empty();
        var data={
            pagenum: pagenum
        }
        if(nameortel!=null){
            data["nameortel"]=nameortel;
        }

        Ajax.get(
            {
                url: `/card/list`,
                data: data
            },
            res => {
                if (res["code"] === 0) {
                    $.each(res.data, function(index, item) {

                        $("#clubList").append(
                            `<ul>
                                <li class="cardinfo">
                                <span class="numb">${item["name"]}</span>
                                <span class="date">${item["tel"]}</span>
                                <span class="name">${item["type"]==2?"现金卡":item["projectname"]}</span>
                                <span class="classification">${item["type"]==2?item["moneyremaining"]:item["timesremaining"]}</span>
                                </li>
                                <span class="btn">
                                <!--                                        <button class="examine">审核</button>-->
                                <button class="cardxiaofei" data-customer="${item["name"]}" data-cardid="${item["id"]}" 
                                data-cardtype="${item["type"]}" data-moneyremaining="${item["moneyremaining"]}" 
                                data-timesremaining="${item["timesremaining"]}" data-projectname="${item["projectname"]}" 
                                data-classify="${item["classify"]}"  data-brandname="${item["brandname"]}"
                                data-pinpai="${item["pinpai"]}" data-category="${item["category"]}"  
                                >消费</button>
                                ${item["type"] == 2 ? "<button class='shengkabtn' data-cardid='" + item["id"] + "' >升卡</button>" : ""}
                                </span>
                            </ul>
                            `
                        );
                    });
                }
            }
        );
    }
    getcard(0);

    $("#sereachPhone").click(function () {
        getcard(0,$("#nameortelinput").val())
    });


    $(document).on("click",".shengkabtn",function () {
        var cardid = this.dataset.cardid;
        $("#shengkaid").val(cardid);
    });

    $(document).on("click","#shengkaButton",function () {
        Ajax.post(
            {
                url: `/card/increasemoney`,
                data: {
                    cardnum:$("#shengkaid").val(),
                    money:$("#shengkamoney").val()
                }
            },
            res => {
                alert(res["msg"]);
                $("#shengkaMask").css("display","none");
            }
        );
    });

    //消费
    $(document).on("click",".cardxiaofei",function () {
        var cardtype = this.dataset.cardtype;
        if (cardtype === '1') {
            $("#huiyuanorder").click();
            console.log($(window.test).parent().parent().children()[0]);
            var select1Origin = $("#consumecategory");
            var select2Origin = $("#consumptionpattern");
            var li1 = select1Origin.parent();
            var li2 = select2Origin.parent();
            select1Origin.remove();
            select2Origin.remove();
            li1.append(`<input value="卡扣卡" id="consumecategory" disabled="disabled">`);
            li2.append(`<input value="卡扣" id="consumptionpattern" disabled="disabled">`);
        } else if (cardtype === '2') {
            window.moneyremaining=this.dataset.moneyremaining;
            window.cardid=this.dataset.cardid;
            window.fromcard=true;
            $("#huiyuanorder").click();
            $("#settlementCustomer").val(this.dataset.customer);
            var select1Origin = $("#consumecategory");
            var li1 = select1Origin.parent();
            select1Origin.remove();
            li1.append(`<input value="卡扣实操" id="consumecategory" disabled="disabled">`);
        }
    });

    //消费
    $(document).on("click","#cardmanagement",function () {
        getcard(0);
    });


    $("#openCard").click(function () {
        var staffInfo = [];
        Ajax.get(
            {
                url:`staff/allstaff`,
            },
            res => {
                if (res["code"]===0){
                    var cashstaff = $("#beauticianCard");
                    var guwenCard = $("#guwenCard");
                    var kakoustaff1 = $("#cardbeautician1");
                    var kakoustaff2 = $("#cardbeautician2");
                    var kakoustaff3 = $("#cardbeautician3");
                    var kakoustaff4 = $("#cardbeautician4");
                    var consultant = $("#cardconsultant");
                    staffInfo = res["data"];
                    for (var i=0;i<staffInfo.length;i++){
                        cashstaff.append(new Option(staffInfo[i]["name"],staffInfo[i]["id"]));
                    }
                    for (var i=0;i<staffInfo.length;i++){
                        guwenCard.append(new Option(staffInfo[i]["name"],staffInfo[i]["name"]));
                    }

                    for (var i=0;i<staffInfo.length;i++){
                        kakoustaff1.append(new Option(staffInfo[i]["name"],staffInfo[i]["id"]));
                    }
                    kakoustaff2.append(new Option("",""));
                    kakoustaff3.append(new Option("",""));
                    kakoustaff4.append(new Option("",""));
                    for (var i=0;i<staffInfo.length;i++){
                        kakoustaff2.append(new Option(staffInfo[i]["name"],staffInfo[i]["id"]));
                    }
                    for (var i=0;i<staffInfo.length;i++){
                        kakoustaff3.append(new Option(staffInfo[i]["name"],staffInfo[i]["id"]));
                    }
                    for (var i=0;i<staffInfo.length;i++){
                        kakoustaff4.append(new Option(staffInfo[i]["name"],staffInfo[i]["id"]));
                    }
                    for (var i=0;i<staffInfo.length;i++){
                        consultant.append(new Option(staffInfo[i]["name"],staffInfo[i]["id"]));
                    }
                }
            }
        )
    });

    $("#openCard").click(function () {
        Ajax.get(
            {
                url:`me`,
            },
            res => {
                if (res["code"]===0){
                    $("#cardTyper").val(res["data"]["name"]);
                    $("#cardchecker").val(res["data"]["name"]);
                }
            }
        )
    });

    $("#openCardButton").click(function () {
       // if ($("#cardType")==="卡扣卡"){
        //        //     var consumptioncategory = $("#cardConsumption").val();
        //        //     var customer = $("#cardCustomer").val();
        //        //     var telephone = $("#telephone").val();
        //        //     var classify = $("#cardClassify").val();
        //        //     var category = $("#kakoucategory").val();
        //        //     var brandname = $("#cardBrandname").val();
        //        //     var pinpai = $("#cardPinpai").val();
        //        //     var projectname = $("#cardProject").val();
        //        //     var courses = $("#cardTimes").val();
        //        //     var hand = $("#cardHand").val();
        //        //     var money = $("#cardMoney").val();
        //        //     var consumptionpattern = $("#cardconsumptionpattern").val();
        //        //     var allocate = $("#cardAllocate").val();
        //        //     var beautician1 = $("#cardbeautician1").val();
        //        //     var beautician2 = $("#cardbeautician2").val();
        //        //     var beautician3 = $("#cardbeautician3").val();
        //        //     var beautician4 = $("#cardbeautician4").val();
        //        //     var cardcategory = "卡扣卡";
        //        //     var consultant = $("#cardconsultant").val();
        //        // }else{
        //        //
        //        // }

        var customer = $("#clubCustomer").val();
        var telephone = $("#customerPhone").val();
        var money = $("#cardMoney").val();
        var beautician = $("#beauticianCard").val();
        var consultant = $("#guwenCard").val();
        var consumptionpattern = $("#cardConsume").val();

        Ajax.post({
            url: `card/addcashcard`,
            data: {
                customer:customer,
                telephone:telephone,
                money:money,
                beautician:beautician,
                consultant:consultant,
                consumptionpattern:consumptionpattern
            }
        }, res => {
            console.log(res);
            alert(res["msg"]);
            $("#openCardMask").css("display","none");
            getcard(0);
        });

    });
});



