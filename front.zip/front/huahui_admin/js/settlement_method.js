var consumeInfo = [["现金卡", "卡扣卡"],
    ["现金实操", "卡扣实操", "赠送实操"], ["现金产品", "卡扣产品", "赠送产品"]];

/*二级联动*/
function selectConsume() {
    $("#consumecategory").empty();
    $("#cardcategory").empty();
    /*获取类别下拉框的内容*/
    var category = $("#category").val();
    /*获取消费类别下拉框的对象*/
    var consumecategory = $("#consumecategory");
    var cardcategory = $("#cardcategory");
    var selectParam;
    var selectOfCard;
    //消费类别联动
    if (category === "卡") {
        selectParam = consumeInfo[0];
        selectOfCard = ["开卡","升卡","续卡"];
    } else if (category === "美容" || category === "美体" || category === "仪器") {
        selectParam = consumeInfo[1];
    } else if (category ==="产品") {
        selectParam = consumeInfo[2];
    }else {
        selectParam = null;
    }

    for (var i = 0; i < selectParam.length; i++) {
        consumecategory.append(new Option(selectParam[i], selectParam[i]));
    }
    for (var i=0;i<selectOfCard.length;i++){
        cardcategory.append(new Option(selectOfCard[i], selectOfCard[i]));
    }


}

function selectConsume3() {
    $("#settlementProject").empty();
    $("#settlementBrandname").empty();
    /*获取类别的内容*/
    var category = $("#category").val();
    var factoryInfo=[];
    Ajax.get(
        {
            url: `brand/getfactorybycategory`,
            data:{
                category: category
            }
        },
        res => {
            if (res["msg"] === "成功") {
                factoryInfo = res["data"];
                /*获取厂家下拉的对象*/
                var settlementBrand = $("#settlementBrandname");
                settlementBrand.append(new Option("请选择"));
                for (var i = 0; i < factoryInfo.length; i++) {
                    settlementBrand.append(new Option(factoryInfo[i], factoryInfo[i]));
                }
            }
        }
    );
}

function selectConsume5() {
    $("#cardProject").empty();
    $("#cardBrandname").empty();
    /*获取类别的内容*/
    var category = $("#kakoucategory").val();
    var factoryInfo=[];
    Ajax.get(
        {
            url: `brand/getfactorybycategory`,
            data:{
                category: category
            }
        },
        res => {
            if (res["msg"] === "成功") {
                factoryInfo = res["data"];
                /*获取厂家下拉的对象*/
                var settlementBrand = $("#cardBrandname");
                settlementBrand.append(new Option("请选择"));
                for (var i = 0; i < factoryInfo.length; i++) {
                    settlementBrand.append(new Option(factoryInfo[i], factoryInfo[i]));
                }
            }
        }
    );
}

//编辑的类别联动
function selectConsume4() {
    $("#editsettlementProject").empty();
    $("#editsettlementBrandname").empty();
    /*获取类别的内容*/
    var category = $("#editcategory").val();
    var factoryInfo=[];
    Ajax.get(
        {
            url: `brand/getfactorybycategory`,
            data:{
                category: category
            }
        },
        res => {
            if (res["msg"] === "成功") {
                factoryInfo = res["data"];
                /*获取厂家下拉的对象*/
                var settlementBrand = $("#editsettlementBrandname");
                settlementBrand.append(new Option("请选择"));
                for (var i = 0; i < factoryInfo.length; i++) {
                    settlementBrand.append(new Option(factoryInfo[i], factoryInfo[i]));
                }
            }
        }
    );
}

function factoryChange() {
    $("#settlementProject").empty();
    $("#settlementPinpai").empty();

    var factoryName = $("#settlementBrandname").val();
    var projectInfo=[];
    Ajax.get(
        {
            url:`brand/getprojectbyfactory`,
            data: {
                factoryname:factoryName
            }
        },
        res => {
            if (res["code"]===0){
                projectInfo = res["data"];
                var settlementProject = $("#settlementProject");
                settlementProject.append(new Option("请选择"));
                for (var i=0;i<projectInfo.length;i++){
                    settlementProject.append(new Option(projectInfo[i]["projectname"],projectInfo[i]["projectid"]));
                }
            }
        }
    );
}

function factoryChange2() {
    $("#editsettlementProject").empty();
    $("#editsettlementPinpai").empty();

    var factoryName = $("#editsettlementBrandname").val();
    var projectInfo=[];
    Ajax.get(
        {
            url:`brand/getprojectbyfactory`,
            data: {
                factoryname:factoryName
            }
        },
        res => {
            if (res["code"]===0){
                projectInfo = res["data"];
                var settlementProject = $("#editsettlementProject");
                settlementProject.append(new Option("请选择"));
                for (var i=0;i<projectInfo.length;i++){
                    settlementProject.append(new Option(projectInfo[i]["projectname"],projectInfo[i]["projectid"]));
                }
            }
        }
    );
}
function factoryChange3() {
    $("#cardProject").empty();
    $("#cardPinpai").empty();

    var factoryName = $("#cardBrandname").val();
    var projectInfo=[];
    Ajax.get(
        {
            url:`brand/getprojectbyfactory`,
            data: {
                factoryname:factoryName
            }
        },
        res => {
            if (res["code"]===0){
                projectInfo = res["data"];
                var cardProject = $("#cardProject");
                cardProject.append(new Option("请选择"));
                for (var i=0;i<projectInfo.length;i++){
                    cardProject.append(new Option(projectInfo[i]["projectname"],projectInfo[i]["projectid"]));
                }
            }
        }
    );
}
function projectChange() {
    var project = $("#settlementProject").val();
    Ajax.get(
        {
            url:`brand/findpinbaibyproject`,
            data: {
                projectid:project
            }
        },
        res => {
            if (res["code"]===0){
                var settlementPinpai = $("#settlementPinpai");
                settlementPinpai.val(res["msg"]==="成功"?"":res["msg"]);
            }
        }
    )
}

function projectChange2() {
    var project = $("#editsettlementProject").val();
    Ajax.get(
        {
            url:`brand/findpinbaibyproject`,
            data: {
                projectid:project
            }
        },
        res => {
            if (res["code"]===0){
                var settlementPinpai = $("#editSettlementPinpai");
                settlementPinpai.val(res["msg"]==="成功"?"":res["msg"]);
            }
        }
    )
}

function projectChange3() {
    var project = $("#cardProject").val();
    Ajax.get(
        {
            url:`brand/findpinbaibyproject`,
            data: {
                projectid:project
            }
        },
        res => {
            if (res["code"]===0){
                var cardPinpai = $("#cardPinpai");
                cardPinpai.val(res["msg"]==="成功"?"":res["msg"]);
            }
        }
    )
}