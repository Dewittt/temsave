// 添加三级分类
$(document).ready(function() {
  var select = $(".allshop");
  select.empty();
  Ajax.get(
    {
      url: `shop/allshop`
    },
    res => {
      if (res["code"] === 0) {
        $.each(res["data"], function(index, item) {
          select.append(
            `<option value="${item.shopid}">${item.shopname}</option>`
          );
        });
      }
    }
  );
});

$(document).ready(function() {
  $("#submitbillsheetselect").click(function() {
    var fileSerialNumberinput = $("#fileSerialNumberinput").val();
    var billsheets = $("#billsheets").val();
    Ajax.post(
      {
        url: `settlement/importexceldata`,
        data: {
          fileSerialNumber: fileSerialNumberinput,
          sheetNames: billsheets
        }
      },
      res => {
        $("#billsheetselect").css("display", "none");
        alert(res.msg);
      }
    );
  });

  $("#closebillsheetselect").click(function() {
    var fileSerialNumberinput = $("#fileSerialNumberinput").val();

    Ajax.post(
      {
        url: `settlement/cancelimport`,
        data: {
          fileSerialNumberinput: fileSerialNumberinput
        }
      },
      res => {
        //pass
      }
    );
  });

  $("#submitbill").click(function() {
    console.log("bill upload");
    Ajax.upload_billfile(
      {
        url: `settlement/updloadexcel`,
        elem: $("#billfile")
      },
      res => {
        $("#billsheetselect").css("display", "block");
        var data = res.data;
        console.log(res);
        $("#fileSerialNumberinput").val(data["fileSerialNumber"]);

        $("#billsheets").empty();

        $.each(data["sheetNames"], function(index, item) {
          $("#billsheets").append(`<option value="${item}">${item}</option>`);
        });
      }
    );
  });
});

$(document).ready(function() {
  function allManufactor(pagenum) {
    Ajax.get(
      {
        url: `brand/getallfactory`,
        data:{pagenum:pagenum}
      },
      res => {
        $('#factorypageTool').empty()
        $("#admanufac").empty()

        if (res["msg"] === "成功") {
          $.each(res["data"], function(index, item) {
            var li = $("<li></li>");
            li.html(
              ` <span class="manufacname">${item.name}</span><div class="btn">
                <button data-factoryid="${item.id}" class="editmanufac">编辑</button>
                <button data-factoryid="${item.id}" class="delmanufac">删除</button></div>`
            );
            console.log(index)
            $("#admanufac").append(li);

          });

          var p = new Paging();
          p.init({
            target: '#factorypageTool',
            pagesize: res["pageinfo"]["pagessize"],
            count: res["pageinfo"]["count"],
            current: res["pageinfo"]["current"],
            callback:function (pagecount) {
              allManufactor(pagecount)
            }
          });
        }
      }
    );
  }

  allManufactor(1);

  $("#addFactory").click(function() {
    let factoryname = $("#addfactoryname").val();
    if (factoryname === "" || factoryname === null) {
      alert("厂家名不能为空");
    } else {
      Ajax.post(
        {
          url: `brand/addfactory`,
          data: {
            factoryname: factoryname
          }
        },
        res => {
          if (res.msg === "成功") {
            $("#manufactor").css("display", "none");
            $("#addfactoryname").val("");
            allManufactor(1);
          } else {
            alert(res.msg);
          }
        }
      );
    }
  });

  //编辑厂家填充
  $(document).on("click", ".editmanufac", function(e) {
    var factoryid=this.dataset.factoryid
    var factoryname = this.parentNode.parentNode.getElementsByClassName("manufacname")[0].innerText;

    console.log(factoryname)

    $("#editfactorynameinput").val(factoryname)
    $("#editfactorynameinput").data("factoryid",factoryid)

  });

  //确认编辑厂家
  $(document).on("click", "#sureeditfactory", function(e) {
    var factoryname = $("#editfactorynameinput").val();
    var factoryid = $("#editfactorynameinput").data("factoryid");

    Ajax.post(
        {
          url: `brand/editfactory`,
          data: {
            factoryname: factoryname,
            factoryid: factoryid
          }
        },
        res => {
          console.log(res)
          alert(res.msg);
          $("#editfactory").css("display", "none");
          allManufactor(1);
          allProject();
        }
    );
  });

  $(document).on("click", "button.delmanufac", function(e) {
    let factoryid = $(this).data("factoryid");
    console.log(factoryid);
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      Ajax.post(
        {
          url: `brand/deletefactory`,
          data: {
            factoryid: factoryid
          }
        },
        res => {
          if (res.msg === "删除成功") {
            allManufactor(1);
            allProject();
          } else {
            alert(res.msg);
          }
        }
      );
    }
  });

  //-下为项目管理--------------------------------------------

  function allProject(pagenum) {
    Ajax.get(
      {
        url: `brand/allproject`,
        data:{pagenum:pagenum}

      },
      res => {
        if (res["error"] === 0) {
          $("#adpromanage").empty();
          $("#projectpageTool").empty();
          $.each(res["data"], function(index, item) {
            var projects = item["projects"];
            for (var i = 0; i < projects.length; i++) {
              var li = $("<li></li>");
              li.html(
                ` <span class="manufacname">${item.name}</span>
                                            <span class="proname">${projects[i]["category"]!=null?projects[i]["category"]:''}</span>
                                            <span class="proname">${projects[i]["pinpai"]!=null?projects[i]["pinpai"]:""}</span>
                                            <span class="proname">${projects[i]["projectname"]!=null?projects[i]["projectname"]:""}</span>
                                            <div class="btn do">
                                                <button data-projectid="${projects[i]["projectid"]}" class="delpro">删除</button></div>
`
              );
              $("#adpromanage").append(li);
            }
          });
          var p = new Paging();
          p.init({
            target: '#projectpageTool',
            pagesize: res["pageinfo"]["pagessize"],
            count: res["pageinfo"]["count"],
            current: res["pageinfo"]["current"],
            callback:function (pagecount) {
              allProject(pagecount)
            }
          });
        }
      }
    );
  }

  allProject();

  $("#addpromanage").click(function() {
    Ajax.get(
      {
        url: `brand/getallfactory`,
        data:{pagenum:-1}
      },
      res => {
        if (res["msg"] === "成功") {
          var select = $("#factoryNameOfProject");
          select.empty();
          $.each(res["data"], function(index, item) {
            select.append(`<option value="${item.id}">${item.name}</option>`);
          });
        }
      }
    );
  });

  $("#addProjectOfFactory").click(function() {

    let category = $("#category").val();
    let pinpainame = $("#pinpainame").val();
    let projectname = $("#projectname").val();
    let factoryid = $("#factoryNameOfProject").val();
    if (projectname === "" || projectname === null) {
      alert("项目名不能为空");
    } else {
      Ajax.post(
        {
          url: `brand/addproject`,
          data: {
            category: category,
            pinpai: pinpainame,
            projectname: projectname,
            factoryid: factoryid
          }
        },
        res => {
          if (res.msg === "成功") {
            $("#projectmanage").css("display", "none");
            $("#projectname").val("");
            allProject();
          } else {
            alert(res.msg);
          }
        }
      );
    }
  });

  $(document).on("click", "button.delpro", function(e) {
    let projectid = $(this).data("projectid");
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      Ajax.post(
        {
          url: `brand/deleteproject`,
          data: {
            projectid: projectid
          }
        },
        res => {
          if (res.msg === "删除成功") {
            allProject();
          } else {
            alert(res.msg);
          }
        }
      );
    }
  });
});
