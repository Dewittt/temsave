$(document).ready(function() {
  // 获取所有支付方式id
  // Ajax.get(
  //   {
  //     url: `settlement/allpaymentmethod`
  //   },
  //   res => {
  //     if (res["msg"] === "成功") {
  //       var data = [
  //         {
  //           id: 1,
  //           name: "XXX"
  //         }
  //       ];
  //       $.each(data, function(index, item) {
  //         var option = $("<option>").html(`<span>${item.name}</span>`);
  //         $("#allpaymentmethod").append(option);
  //       });
  //     }
  //   }
  // );

  /* 列出所有settlement*/
  function allSettlement(sday,eday,pagenum) {

    Ajax.get(
        {
          url: `settlement/all`,
          data:{createtime:sday,endtime:eday,pagenum:pagenum}
        },
        res => {
          if (res["msg"] === "成功") {
            $("#settlementList").empty();
            $.each(res.data, function(index, item) {
              var ul = $("<ul></ul>");
              ul.html(
                  `<li data-settlementid="${item.settltmentid}" class="custinfor">
                                        <span class="numb">${item.settltmentid}</span>
                                        <span class="date">${item.time}</span>
                                        <span class="name">${item.customer}</span>
                                        <span class="classification">${item.classify}</span>
                                        <span class="category">${item.category}</span>
                                        <span class="brand">${item.brandname}</span>
                                        <span class="projectname">${item.projectname}</span>
                                        <span class="mon">${item.money}</span>
                                        <span class="room">${item.consumptioncategory}</span>
                                        <span class="cuscate">${item.consumptionpattern}</span>
                                        <span class="beautician">${item.beautician}</span>
                                    </li><span class="btn"><button data-settlementid="${item.settltmentid}" class="write">编辑</button><button data-settlementid="${item.settltmentid}" class="del">删除</button></span>`
              );
              $("#settlementList").append(ul);
            });
            var p = new Paging();
            $("#settlementpageTool").empty()
            p.init({
              target: '#settlementpageTool',
              pagesize: res["pageinfo"]["pagessize"],
              count: res["pageinfo"]["count"],
              current: res["pageinfo"]["current"],
              callback:function (pagecount) {
                var start = $("#test-n9").text();
                var end = $("#test-n8").text();
                allSettlement(start,end,pagecount);
              }
            });
          }
        }
    );
  }
  var date = new Date();
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  if (month < 10) {
    month = "0" + month;
  }
  if (day < 10) {
    day = "0" + day;
  };
  var currentdate = year + '-' + month + '-' + day;

  allSettlement(currentdate,currentdate);

  $("#settlementQuery").click(function () {
    var start = $("#test-n9").text();
    var end = $("#test-n8").text();
    allSettlement(start,end);
  });

  $("#huiyuanorder").click(function () {
    $("#addsettlement").css("display", "block");
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    if (month < 10) {
      month = "0" + month;
    }
    if (day < 10) {
      day = "0" + day;
    }
    ;
    var currentdate = year + '-' + month + '-' + day;
    $("#createTime").val(currentdate);
    Ajax.get(
        {
          url: `staff/allstaff`
        },
        res => {
          if (res["msg"] === "成功") {

            $("#beautician1").empty();
            $("#beautician2").empty();
            $("#beautician3").empty();
            $("#beautician4").empty();
            $("#beautician2").append(new Option(" "));
            $("#beautician3").append(new Option(" "));
            $("#beautician4").append(new Option(" "));
            $("#consultant").append(new Option(" "));
            for (var i = 0; i < res["data"].length; i++) {
              $("#beautician1").append(new Option(res["data"][i]["name"], res["data"][i]["id"]));
              $("#beautician2").append(new Option(res["data"][i]["name"], res["data"][i]["id"]));
              $("#beautician3").append(new Option(res["data"][i]["name"], res["data"][i]["id"]));
              $("#beautician4").append(new Option(res["data"][i]["name"], res["data"][i]["id"]));

              $("#consultant").append(new Option(res["data"][i]["name"], res["data"][i]["name"]));


            }
          }
        }
    );
  });


  $("#settlementMoney").change(function () {

    if (window.fromcard==true){
      if(window.moneyremaining<$("#settlementMoney").val()){
        $("#settlementMoney").val("")
        alert("卡余额不足，当前余额"+window.moneyremaining+"元")
      }
    }
  });

  //添加结算单
  $("#addsettlement .finish").click(function () {
    var createtime = $("#test-e17").text();
    var customer = $("#addsettlement #settlementCustomer").val();
    var classify = $("#addsettlement #settlementClassify").val();
    var category = $("#addsettlement #category").val();
    var brandname = $("#addsettlement #settlementBrandname").val();
    var projectname = $("#addsettlement #settlementProject").find("option:selected").text();
    var times = $("#addsettlement #settlementTimes").val();
    var hand = $("#addsettlement #settlementHand").val();
    var money = $("#addsettlement #settlementMoney").val();
    var consumptioncategory = $("#addsettlement #consumecategory").val();
    var consumptionpattern = $("#addsettlement #consumptionpattern").val();
    var allocate = $("#addsettlement #allocate").val();
    var beautician1 = $("#addsettlement #beautician1").val();
    var beautician2 = $("#addsettlement #beautician2").val();
    var beautician3 = $("#addsettlement #beautician3").val();
    var beautician4 = $("#addsettlement #beautician4").val();
    var cardcategory = $("#addsettlement #cardcategory").val();
    var consultant = $("#addsettlement #consultant").val();
    var checker = $("#addsettlement #checker").val();
    var pinpai = $("#settlementPinpai").val();
    var createTime = $("#addsettlement #createTime").val();
    var telephone = $("#settlementCustomerTel").val();
    var courses = $("#coursesTimes").val();

    var data={
      createtime:createtime,
      customer:customer,
      classify:classify,
      category:category,
      brandname:brandname,
      projectname:projectname,
      times:times,
      hand:hand,
      money:money,
      consumptioncategory:consumptioncategory,
      consumptionpattern:consumptionpattern,
      allocate:allocate,
      beautician1:beautician1,
      beautician2:beautician2,
      beautician3:beautician3,
      beautician4:beautician4,
      cardcategory:cardcategory,
      consultant:consultant,
      checker:checker,
      pinpai:pinpai,
      telephone:telephone,
      courses:courses
    };

    if (window.fromcard==true){
      data["fromcard"]=true;
      data["fromcardnum"]=window.cardid;
    }
    if(window.fromcreatekakoucard){
      data["fromcreatekakoucard"]=true;
    }else {
      data["fromcreatekakoucard"]=false;
    }

    Ajax.post({
      url: `settlement/add`,
      data: data
    },res => {
      window.fromcard=false;

      if (res["code"]===0){
        $("#addsettlement #settlementCustomer").val("");
        $("#addsettlement #settlementBrandname").val("");
        $("#addsettlement #settlementProject").val("");
        $("#addsettlement #settlementTimes").val("");
        $("#addsettlement #settlementHand").val("");
        $("#addsettlement #settlementMoney").val("");
        $("#addsettlement #consultant").val("");
        $("#addsettlement #checker").val("");
        $("#addsettlement #createTime").val("");
        $("#addsettlement #settlementPinpai").val("");
        //回复固定情况
        var li1 = $("#consumecategory").parent();
        var li2 = $("#consumptionpattern").parent();
        li1.empty();
        li1.append(` <span class="room">消费类别</span>
                            <select name="consumptioncategory" id="consumecategory">`);
        li2.empty();
        li2.append(`<span class="cuscate">消费方式</span>
                            <select name="consumptionpattern" id="consumptionpattern">
                                <option value="卡扣">卡扣</option>
                                <option value="现金">现金</option>
                                <option value="赠送">赠送</option>
                                <option value="微信">微信</option>
                                <option value="支付宝">支付宝</option>
                                <option value="POS机">POS机</option>
                            </select>`);
        $("#addsettlement").css("display", "none");
        alert(res["msg"]);
        allSettlement(currentdate,currentdate);
      }else {
        alert(res["msg"]);
      }
    });
  });

  //删除结算单
  $(document).on("click","#settlementList .del",function (e) {
    var settlementid = $(this).data("settlementid");
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      Ajax.post(
          {
            url: `settlement/deleteone`,
            data: {
              settlementid: settlementid
            }
          },
          res => {
            if (res.msg === "删除成功") {
              allSettlement(currentdate,currentdate);
            } else {
              alert("删除失败，请稍后重试。");
            }
          }
      );
    } else {
      console.log("你点击了取消");
    }

  });

  //编辑结算单
  $(document).on("click", "#settlementList button.write", function (e) {
    $("#editsettlement").css("display","block");
    var settlementid = $(this).data("settlementid");
    sessionStorage.setItem("settlementid",settlementid);
    Ajax.get(
        {
          url: `staff/allstaff`
        },
        res => {
          if (res["msg"] === "成功") {
            $("#editBeautician1").empty();
            $("#editBeautician2").empty();
            $("#editBeautician2").append(new Option(" "));
            for (var i = 0; i < res["data"].length; i++) {
              $("#editBeautician1").append(new Option(res["data"][i]["name"], res["data"][i]["id"]))
              ;
              $("#editBeautician2").append(new Option(res["data"][i]["name"], res["data"][i]["id"]));
            }
          }
        }
    );
    Ajax.get(
        {
          url: `settlement/selectone`,
          data:{settlementid:settlementid}
        },
        res => {
          if (res["msg"] === "成功") {
            $("#editSettlementCustomer").val(res.data["customer"]);
            $("#editSettlementClassify").val(res.data["classify"]);
            $("#editSettlementBrandname").val(res.data["brandname"]);
            $("#editSettlementTimes").val(res.data["times"]);
            $("#editSettlementMoney").val(res.data["money"]);
            $("#editSettlementHand").val(res.data["hand"]);
            $("#editSettlementProject").val(res.data["projectname"]);
            $("#editConsultant").val(res.data["sonsultant"]);
            $("#editChecker").val(res.data["checker"]);
            $("#editConsumecategory").val(res.data["consumecategory"]);
            $("#editCardcategory").val(res.data["cardcategory"]);
            $("#editConsumptionpattern").val(res.data["consumptionpattern"]);
            $("#editAllocate").val(res.data["allocate"]);
            $("#editCreateTime").val(res.data["time"]);
          }
        }
    );

  });

  //提交修改结算单
  $("#editFinish").click(function () {
    var customer = $("#editsettlement #editSettlementCustomer").val();
    var classify = $("#editsettlement #editSettlementClassify").val();
    var category = $("#editsettlement #editcategory").val();
    var brandname = $("#editsettlement #editsettlementBrandname").val();
    var projectname = $("#editsettlement #editsettlementProject").find("option:selected").text();
    var times = $("#editsettlement #editSettlementTimes").val();
    var hand = $("#editsettlement #editSettlementHand").val();
    var money = $("#editsettlement #editSettlementMoney").val();
    var consumptioncategory = $("#editsettlement #editConsumecategory").val();
    var consumptionpattern = $("#editsettlement #editConsumptionpattern").val();
    var pinpai = $("#editSettlementPinpai").val();
    var allocate = $("#editsettlement #editAllocate").val();
    var beautician1 = $("#editsettlement #editBeautician1").val();
    var beautician2 = $("#editsettlement #editBeautician2").val();
    var beautician3 = $("#editsettlement #editBeautician3").val();
    var beautician4 = $("#editsettlement #editBeautician4").val();
    var cardcategory = $("#editsettlement #editCardcategory").val();
    var consultant = $("#editsettlement #editConsultant").val();
    var checker = $("#editsettlement #editChecker").val();
    var createTime = $("#editsettlement #editCreateTime").val();
    var settlementid = sessionStorage.getItem("settlementid");
    Ajax.post({
      url: `settlement/update`,
      data: {
        settlementid:settlementid,
        customer:customer,
        classify:classify,
        category:category,
        brandname:brandname,
        projectname:projectname,
        times:times,
        hand:hand,
        pinpai:pinpai,
        money:money,
        consumptioncategory:consumptioncategory,
        consumptionpattern:consumptionpattern,
        allocate:allocate,
        beautician1:beautician1,
        beautician2:beautician2,
        beautician3:beautician3,
        beautician4:beautician4,
        cardcategory:cardcategory,
        consultant:consultant,
        checker:checker,
        createtime:createTime
      }
    },res => {
      if (res["code"]===0){
        $("#editsettlement #editSettlementCustomer").val("");
        $("#editsettlement #editSettlementBrandname").val("");
        $("#editsettlement #editSettlementProject").val("");
        $("#editsettlement #editSettlementTimes").val("");
        $("#editsettlement #editSettlementHand").val("");
        $("#editsettlement #editSettlementMoney").val("");
        $("#editsettlement #editConsultant").val("");
        $("#editsettlement #editChecker").val("");
        $("#editsettlement #editCreateTime").val("");
        $("#editsettlement").css("display", "none");
        alert(res["msg"]);
        allSettlement(currentdate,currentdate);
      }
    });
  });

  //   新的结算单
  $(".newcustor").click(function() {
    var customername = $("#customername").val();
    var peoplenum = $("#peoplenum").val();
    var roomname = $("#roomname").val();
    var consultantid = $("#consultantid").val();
    var paymentmethod = $("#allpaymentmethod").val();
    var projectid = $("#allprojectid").val();
    var times = $("#alltimes").val();
    var price = $("#allprice").val();
    var staff1 = $("#allstaff1").val();
    var staff2 = $("#allstaff2").val();
    Ajax.post({
      url: `settlement/addsettlement`,
      data: {
        customername: customername,
        peoplenum: peoplenum,
        roomname: roomname,
        consultantid: consultantid,
        paymentmethod: paymentmethod,
        settlementitems: [
          //settlementitems结算单具体项目,array
          {
            projectid: projectid,
            times: times,
            price: price,
            staff1: staff1,
            staff2: staff2
          }
        ]
      }
    },res => {
      console.log(res);
    });
  });
});
