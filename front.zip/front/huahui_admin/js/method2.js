//定义一个处理字符串的方法
function StringBuffer(str) {
  var arr = [];
  str = str || "";
  arr.push(str);

  //追加字符串
  this.append = function(str1) {
    arr.push(str1);
    return this;
  };
  //返回追加的字符串
  this.toString = function() {
    return arr.join("");
  };
  //清空
  this.clear = function() {
    arr = [];
  };
  //返回数组大小
  this.size = function() {
    return arr.length;
  };
  //返回数组
  this.toArray = function() {
    return arr;
  };
  //倒序返回字符串
  this.doReverse = function() {
    return arr.reverse().join("");
  };
}
//页面加载完成生成省份的下拉列表
$(function() {
  //遍历区域json数据，以0000结尾的都是省/直辖市/自治区/特别行政区
  var strBufferObj = new StringBuffer();
  $.each(cityJson, function(index, areaValue) {
    var suffix = areaValue.item_code.substr(2, 4);
    if (suffix == "0000") {
      strBufferObj.append(
        "<option value='" +
          areaValue.item_code +
          "'>" +
          areaValue.item_name +
          "</option>"
      );
    }
  });
  $("#editchoosePro").after(strBufferObj.toString());
});
//选择省份之后生成市列表
function doProvAndCityRelation2() {
  //先清除以前的市的列表
  $("#editcitys").empty();
  $("#editcounty").empty();
  //生成请选择您所在城市
  $("#editcitys").append(
    "<option value='-1' id='editchooseCity'>请选择您所在城市</option>"
  );
  $("#editcounty").append(
    "<option value='-1' id='editchooseCounty'>请选择您所在区/县</option>"
  );
  //获取当前选中的省份
  var province = $("#editprovince").val();
  var strBufferObj = new StringBuffer();
  $.each(cityJson, function(index, areaValue) {
    if (
      areaValue.item_code.substr(0, 2) == province.substr(0, 2) &&
      areaValue.item_code.substr(2, 4) != "0000" &&
      areaValue.item_code.substr(4, 2) == "00"
    ) {
      strBufferObj.append(
        "<option value='" +
          areaValue.item_code +
          "'>" +
          areaValue.item_name +
          "</option>"
      );
    }
  });
  $("#editchooseCity").after(strBufferObj.toString());
}
//选择市之后生成县/区列表
function doCityAndCountyRelation2() {
  //先清除以前的市的列表
  $("#editcounty").empty();
  //生成 请选择您所在区/县
  $("#editcounty").append(
    "<option value='-1' id='editchooseCounty'>请选择您所在区/县</option>"
  );

  //获取当前选中的市
  var city = $("#editcitys").val();
  var strBufferObj = new StringBuffer();
  $.each(cityJson, function(index, areaValue) {
    var suffix = areaValue.item_code.substr(2, 4);
    if (
      city == "110100" ||
      city == "120100" ||
      city == "310100" ||
      city == "500100"
    ) {
      if (
        areaValue.item_code.substr(0, 3) == city.substr(0, 3) &&
        areaValue.item_code.substr(4, 2) !== "00"
      ) {
        strBufferObj.append(
          "<option value='" +
            areaValue.item_code +
            "'>" +
            areaValue.item_name +
            "</option>"
        );
      }
    } else {
      if (
        areaValue.item_code.substr(0, 4) == city.substr(0, 4) &&
        areaValue.item_code.substr(4, 2) !== "00"
      ) {
        strBufferObj.append(
          "<option value='" +
            areaValue.item_code +
            "'>" +
            areaValue.item_name +
            "</option>"
        );
      }
    }
  });
  $("#editchooseCounty").after(strBufferObj.toString());
}
// function showAddr() {
//   var addrShow = $("addr-show");
//   var prov = $("prov");
//   var city = $("city");
//   var country = $("country");
//   addrShow.value =
//     provice[current.prov].name +
//     "-" +
//     provice[current.prov]["city"][current.city].name +
//     "-" +
//     provice[current.prov]["city"][current.city].districtAndCounty[
//       current.country
//     ];
// }
