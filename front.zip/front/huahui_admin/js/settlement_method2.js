var consumeInfo = [["现金卡", "卡扣卡"],
    ["现金实操", "卡扣实操", "赠送实操"], ["现金产品", "卡扣产品", "赠送产品"]];

/*二级联动*/
function selectConsume2() {
    $("#editConsumecategory").empty();
    $("#editCardcategory").empty();
    /*获取类别下拉框的内容*/
    var category = $("#editcategory").val();
    /*获取消费类别下拉框的对象*/
    var consumecategory = $("#editConsumecategory");
    var cardcategory = $("#editCardcategory");
    var selectParam;
    var selectOfCard;
    //消费类别联动
    if (category === "卡") {
        selectParam = consumeInfo[0];
        selectOfCard = ["开卡","升卡","续卡"];
    } else if (category === "美容" || category === "美体" || category === "仪器") {
        selectParam = consumeInfo[1];
    } else if (category ==="产品") {
        selectParam = consumeInfo[2];
    }else {
        selectParam = null;
    }

    for (var i = 0; i < selectParam.length; i++) {
        consumecategory.append(new Option(selectParam[i], selectParam[i]));
    }
    for (var i=0;i<selectOfCard.length;i++){
        cardcategory.append(new Option(selectOfCard[i], selectOfCard[i]));
    }


}