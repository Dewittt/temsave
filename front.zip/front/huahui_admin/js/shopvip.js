$(document).ready(function () {
  // 列出所有会员
  function allShopVip() {
    Ajax.get({
      url: `shopvip/all`
    }, res => {
      if (res["msg"] === "成功") {
        var ul = $("<ul>");
        //   var data = res["data"];
        //   allshop = data;

        $.each(res.data, function (index, item) {
          var li = $("<li></li>");
          li.html(
            `<span class="name">${item.vipname}</span><span class="cardnum">${item.vipname}</span><span class="sex">${item.male}</span><span class="age">${item.age}</span><span class="tel">${item.telephone}</span><span class="zhidinggu">${item.consultant}</span><span class="meione">${item.beautician}</span><span class="meitwo">${item.vipname}</span><div class="butn"><button>编辑</button><button id="delhuiyuan" data-vipid="${item.vipid}">删除</button></div>`
          );
          ul.append(li);
        });
        $(".huiyuanlist").append(ul);
      }
    });
  }

  allShopVip();

  //   删除会员
  $(document).on("click", "#delhuiyuan", function (e) {
    var vipid = $(this).data("vipid");
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      Ajax.post({
        url: `shopvip/delete`,
        data: {
          vipid: vipid
        }
      }, res => {
        if (res.msg === "删除成功") {
          // allShop();
        } else {
          alert("删除失败，请稍后重试。");
        }
      });
    } else {
      console.log("你点击了取消");
    }
  });

  //   添加会员
  $("#addvip").click(function () {
    var vipname = $("#vipname").val();
    var male = $("#male")
    .find("option:selected")
    .text();
    male === "男"
    ? (male = 0)
    : (male = 1);
    var age = $("#age").val();
    var telephone = $("#telephone").val();
    var shopid = $("#vipname").val();
    var consultant = $("#consultant").val();
    var beautician = $("#beautician")
    .find("option:selected")
    .text();
    Ajax.post({
      url: `shopvip/add`,
      data: {
        vipname: vipname,
        male: male,
        age: age,
        telephone: telephone,
        // isnew:
        // shopid:
        consultant: consultant,
        beautician: beautician
      }
    }, res => {
      if (res["code"] === 0) {
        var ul = $("<ul>");
        $("#huidang").css("display", "none");
        var data = [
          {
            vipname: vipname,
            male: male,
            age: age,
            telephone: telephone,
            // isnew:
            // shopid:
            consultant: consultant,
            beautician: beautician
          }
        ];
        $.each(data, function (index, item) {
          var li = $("<li>").html(
            ` <span class="name">${item.vipname}</span><span class="cardnum">142542547</span><span class="sex">${item.male}</span><span class="age">${item.age}</span><span class="tel">15725644475<span><span class="zhidinggu">${item.consultant}</span><span class="meione">${item.beautician}</span><span class="meitwo">李一</span><div class="butn"><button>编辑</button><button id="delhuiyuan" data-vipid="${item.vipid}>删除</button></div>`
          );
          ul.append(li);
        });
        $(".huiyuanlist").append(ul);
      } else {
        alert(res.msg);
      }
    });
  });

  /*按姓名查找会员*/
  $("#searvip").click(function () {
    var vipname = $("#selVipName").val();

    Ajax.get({
      url: `shopvip/find`,
      data: {
        vipname: vipname
      }
    }, res => {
      if (res["msg"] === "成功") {
        //   var data = res["data"];
        //   allshop = data;

        $.each(res.data, function (index, item) {
          var tr = $("<tr></tr>");
          tr.html(`<td>${item.vipname}</td><td>${item.vipnumber}</td><td>${item.male===0?'男':'女'}</td><td>${item.age}</td><td>${item.telephone}</td><td>${item.consultant}</td><td>${item.beautician}</td><td><button class="choosevip" data-vid="${item.vipid}">选择</button></td>`).addClass("xiangqing vipxiangqing");
          $("#viplist").append(tr);
        });
      } else {
        alert(res["msg"]);
      }
    });
  });

  /*选择会员*/
  $(document).on("click", ".choosevip", function (e) {
    var vipid = $(this).data("vid");
    console.log("会员ID",vipid);
  });
});
