$(document).ready(function () {
    //显示标题
    Ajax.get(
        {
            url: `me`
        },
        res => {
            if (res.code == 0) {
                $("#title").text(res["data"]["name"]);
            }
        }
    );


})