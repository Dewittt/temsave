$(function() {
  $("#J_radio")
    .on("click", function() {
      var ischecked = $(this).data("checked");
      if (!ischecked && this.checked) {
        $(this).data("checked", true);
      } else {
        $(this).prop("checked", false);
        $(this).data("checked", false);
      }
      console.log($(this).data("checked"));
    })
    .data("checked", $("#J_radio").get(0).checked);
});