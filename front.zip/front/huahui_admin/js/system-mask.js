$(document).ready(function() {
  $("#addbuss").click(function() {
    $("#addshop").css("display", "block");
  });
  $("#close").click(function() {
    $("#addshop").css("display", "none");
  });
  $("#addshangpin").click(function() {
    $("#pinpai").css("display", "block");
  });
  $("#closepinpai").click(function() {
    $("#pinpai").css("display", "none");
  });
  $("#addleader").click(function() {
    $("#leader").css("display", "block");
  });
  $("#closeleader").click(function() {
    $("#leader").css("display", "none");
  });
  $("#huiyuanorder").click(function() {
    $("#addjiesuan").css("display", "block");
  });
  $("#closejie").click(function() {
    $("#addjiesuan").css("display", "block");
  });
  $(".closeadd").click(function() {
    $("#addjiesuan").css("display", "none");
  });
  $("#neworder").click(function() {
    $("#xinke").css("display", "block");
  });
  $("#closexinke").click(function() {
    $("#xinke").css("display", "none");
  });
  $("#adddangan").click(function() {
    $("#dangan").css("display", "block");
  });
  $("#closedang").click(function() {
    $("#dangan").css("display", "none");
  });
  $("#kefen").click(function() {
    $("#daodian").css("display", "block");
  });
  $("#closeke").click(function() {
    $("#daodian").css("display", "none");
  });
  $("#addproject").click(function() {
    $("#project").css("display", "block");
  });
  $("#clopro").click(function() {
    $("#project").css("display", "none");
  });

  $(document).on("click", ".editstaff", function(e) {
    $("#changestaff").css("display", "block");
  });
  $("#closestaff").click(function() {
    $("#changestaff").css("display", "none");
  });
  $(document).on("click", ".editshop", function(e) {
    console.log("111");
    $("#changeshop").css("display", "block");
    sessionStorage.setItem("shopid", $(this).data("shopid"));
  });
  $(document).on("click", ".editstaff", function(e) {
    $("#changedangan").css("display", "block");
  });
  $("#addproleibie").click(function() {
    $("#addprolei").css("display", "block");
  });
  $("#cloprolei").click(function() {
    $("#addprolei").css("display", "none");
  });
  $("#addhuian").click(function() {
    $("#huidang").css("display", "block");
  });
  $("#closehuidang").click(function() {
    $("#huidang").css("display", "none");
  });
  $("#closeshop").click(function() {
    $("#changeshop").css("display", "none");
  });
  $("#addmanufactor").click(function() {
    $("#manufactor").css("display", "block");
  });
  $(document).on("click", ".editmanufac", function(e) {
    $("#editfactory").css("display", "block");
  });

  $(document).on("click", "#closeeditmanufactor", function(e) {
    $("#editfactory").css("display", "none");
  });

  $("#closemanufactor").click(function() {
    $("#manufactor").css("display", "none");
  });
  $(document).on("click", ".changemanufac", function(e) {
    $("#editmanufactor").css("display", "block");
  });
  $(document).on("click", ".closeeditmanufa", function(e) {
    $("#editmanufactor").css("display", "none");
  });
  $(document).on("click", ".changeadmin", function(e) {
    $("#leaderchange").css("display", "block");
  });
  $(document).on("click", "#closeleader", function(e) {
    $("#leaderchange").css("display", "none");
  });
  $(document).on("click", "#closepinpai", function(e) {
    $("#changepinpai").css("display", "none");
  });
  $(document).on("click", "#closeshopdetail", function (e) {
    $("#shopdetail").css("display","none");
  });
  $("#addpromanage").click(function() {
    $("#projectmanage").css("display", "block");
  });
  $("#closeprojectmanage").click(function() {
    $("#projectmanage").css("display", "none");
  });

  $("#closebillsheetselect").click(function() {
    $("#billsheetselect").css("display", "none");
  });

  $(document).on("click", ".chanpromanage", function(e) {
    $("#editpromanage").css("display", "block");
  });
  $(document).on("click", "#closedeitpro", function(e) {
    $("#editpromanage").css("display", "none");
  });
  $("#addentry").click(function() {
    $("#entryclerk").css("display", "block");
  });
  $("#closentry").click(function() {
    $("#entryclerk").css("display", "none");
  });
  $(document).on("click", "#body>li", function(e) {
    $("#prodetails").css("display", "block");
  });
  $(document).on("click", "#closeprodetails", function(e) {
    $("#prodetails").css("display", "none");
  });
  $(document).on("click", "#closeanalydetail", function(e) {
    $("#analydetail").css("display", "none");
  });

  $(document).on("click", ".custinfor", function(e) {
    $("#settlement").css("display", "block");
    console.log($(this).data("settlementid"));
    var settlementid = $(this).data("settlementid");
    Ajax.get(
      {
        url: `settlement/selectone`,
        data: { settlementid: settlementid }
      },
      res => {
        if (res["msg"] === "成功") {
          $("#imforList").empty();
          var item = res.data;
          var u1 = $("<ul class='left'></ul>");
          var u2 = $("<ul class='right'></ul>");
          u1.html(
            `
                            <li>
                                <span class="date">日期</span>
                                <p>${item.time}</p>
                            </li>
                            <li>
                                <span class="classification">分类</span>
                                <p>${item.classify}</p>
                            </li>
                            <li>
                                <span class="brand">厂家</span>
                                <p>${item.brandname}</p>
                            </li>
                            <li>
                                <span class="numbe">数量</span>
                                <p>${item.times}</p>
                            </li>
                            <li>
                                <span class="mon">金额</span>
                                <p>${item.money}</p>
                            </li>
                            <li>
                                <span class="cuscate">消费方式</span>
                                <p>${item.consumptionpattern}</p>
                            </li>
                            <li>
                                <span class="beautician">美容师</span>
                                <p>${item.beautician}</p>
                            </li>
                            <li>
                                <span class="adviser">顾问</span>
                                <p>${item.sonsultant}</p>
                            </li>`
          );
          u2.html(`
                            <li>
                                <span class="category">类别</span>
                                <p>${item.category}</p>
                            </li>
                            <li>
                                <span class="projectname">项目名</span>
                                <p>${item.projectname}</p>
                            </li>
                            <li>
                                <span class="manual">手工</span>
                                <p>${item.hand}</p>
                            </li>
                            <li>
                                <span class="room">消费类别</span>
                                <p>${item.consumptioncategory}</p>
                            </li>
                            <li>
                                <span class="point">指/非/新</span>
                                <p>${item.allocate}</p>
                            </li>
                            <li>
                                <span class="cardcate">卡项类别</span>
                                <p>${item.cardcategory}</p>
                            </li>
                            <li>
                                <span class="auditor">审核人</span>
                                <p>${item.checker}</p>
                            </li>`);
          $("#imforList").append(u1);
          $("#imforList").append(u2);
        }
      }
    );
  });
  $(document).on("click", "#closeeditsett", function(e) {
    $("#editsettlement").css("display", "none");
  });
  $(document).on("click", "#closesettlement", function(e) {
    $("#settlement").css("display", "none");
  });
  $(document).on("click", "#closeprojectdetail", function(e) {
    $("#projectdetail").css("display", "none");
  });
  $(document).on("click", "#closeoperationdetail", function(e) {
    $("#operationdetail").css("display", "none");
  });
  $(document).on("click", ".finish", function(e) {
    $("#settlement").css("display", "none");
  });
  $("#closeaddsett").click(function() {
    window.fromcard=false;
    window.fromcreatekakoucard=false;
    //回复固定情况
    var li1 = $("#consumecategory").parent();
    var li2 = $("#consumptionpattern").parent();
    li1.empty();
    li1.append(` <span class="room">消费类别</span>
                            <select name="consumptioncategory" id="consumecategory">`);
    li2.empty();
    li2.append(`<span class="cuscate">消费方式</span>
                            <select name="consumptionpattern" id="consumptionpattern">
                                <option value="卡扣">卡扣</option>
                                <option value="现金">现金</option>
                                <option value="赠送">赠送</option>
                                <option value="微信">微信</option>
                                <option value="支付宝">支付宝</option>
                                <option value="POS机">POS机</option>
                            </select>`);
    $("#addsettlement").css("display", "none");
  });
  $("#openCard").click(function () {
      $("#openCardMask").css("display","block");
  });

  $(document).on("click",".shengkabtn",function () {
    $("#shengkaMask").css("display","block");

  });

  $(document).on("click","#closeOpenCard",function () {
    $("#openCardMask").css("display","none");
  });

  $(document).on("click","#closeshengka",function () {
    $("#shengkaMask").css("display","none");
  });

});
