var alladmin = null;
// var allbrand = null;
$(document).ready(function() {
  /*获取标题*/
  Ajax.get(
    {
      url: `setting/websitename`
    },
    res => {
      if (res["msg"] === "成功") {
        $(".websitename").val(res.data.name);
        $("#titlename").text(res.data.name);
      }
    }
  );

  /*列出所有品牌*/
  function allBrand(pagenum) {
    Ajax.get(
      {
        url: `brand/allbrand`,
        data:{pagenum:pagenum}
      },
      res => {
        $('#pageTool').empty()
        if (res["msg"] === "成功") {
          $("#brlist").empty();
          $.each(res.data, function(index, item) {
            var li = $("<li></li>");
            li.html(
              ` <p id="brandname">${item.name}</p><span id="branddescription">${item.description}</span><img id="brandavatar" src="${Ajax.url}/${item.avatar}" alt=""><span style="
    padding: 0 0px 0 0px;
    width: 370px;
">${item.position.indexOf("null")!=-1?'':item.position}</span><button  class="changebrand" data-name="${item.name}" data-description="${item.description}"
              data-avatar="${item.avatar}" data-bid="${item.id}">编辑</button><button class="delbrand del" data-bid="${item.id}">删除</button>`
            );
            $("#brlist").append(li);

          });
          var p = new Paging();
          p.init({
            target: '#pageTool',
            pagesize: res["pageinfo"]["pagessize"],
            count: res["pageinfo"]["count"],
            current: res["pageinfo"]["current"],
            callback:function (pagecount) {
              allBrand(pagecount)
            }
          });
        }
      }
    );
  }

  allBrand();

  /* 列出所有admin*/
  function allAdmin(page) {
    Ajax.get(
      {
        url: `admin/alladmin`,
        data:{page:page}
      },
      res => {
        $('#adminpageTool').empty()
        if (res["msg"] === "成功") {
          $("#addlist").empty();
          $.each(res.data, function(index, item) {
            var li = $("<li></li>");
            li.html(
              `<p>${item.name}</p><span >${item.id}</span><button class="deladmin del" data-uid="${item.id}">删除</button>`
            );
            $("#addlist").append(li);
          });
          var p = new Paging();
          p.init({
            target: '#adminpageTool',
            pagesize: res["pageinfo"]["pagessize"],
            count: res["pageinfo"]["count"],
            current: res["pageinfo"]["current"],
            callback:function (pagecount) {
              allAdmin(pagecount)
            }
          });
        }
      }
    );
  }

  allAdmin();

  /*删除admin*/
  $(document).on("click", ".deladmin", function(e) {
    var userid = $(this).data("uid");
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      console.log("你点击了确定");
      Ajax.post(
        {
          url: `admin/deladminuser`,
          data: {
            userid: userid
          }
        },
        res => {
          if (res.msg === "删除成功") {
            alert("删除成功");
            allAdmin();
          } else {
            alert(res.msg)
          }
        }
      );
    } else {
      console.log("你点击了取消");
    }
  });
  /*添加admin*/
  $("#addadmin").click(function() {
    let username = $("#adminname").val();
    let password = $("#adminpassword").val();
    let repeatpassword = $("#repeatword").val();
    /*验证密码*/
    if (password !== repeatpassword) {
      alert("请输入相同密码");
      return false;
    }
    if (12 < brandpasswd.length || repeatbrandpasswd.length < 6) {
      alert("密码不能大于12位数且不能少于6位数");
      return false;
    }
    Ajax.post(
      {
        url: `admin/addadminuser`,
        data: {
          username: username,
          password: password,
          repeatpassword: repeatpassword
        }
      },
      res => {
        if (res.msg === "创建成功") {
          /*重置输入*/
          // $("#adminname").val("");
          // $("#adminpassword").val("");
          // $("#repeatword").val("");

          $(".adlist").empty();
          allAdmin();
          $("#leader").css("display", "none");
          $.each(res.data, function(index, item) {
            var li = $("<li>").html(
              `<p>${item.username}</p><span>${item.userid}</span><button class="deladmin del" data-uid="1">删除</button>`
            );
            $(".adlist").append(li);
          });
        } else {
          alert(res.msg);
        }
      }
    );
  });
  // 查询admin
  $(".searchadmin").click(function() {
    var keyword = $(".adminkeyword").val();
    console.log(keyword);
    if (keyword.trim() != "") {
      Ajax.post(
        {
          url: `admin/queryadmin`,
          data: {
            keyword: keyword
          }
        },
        res => {
          $(".adlist").empty();
          if (res.data.length !== 0) {
            var data = res.data || [];
            $.each(data, function(index, item) {
              var li = $("<li></li>");
              li.html(
                ` <p>${item.username}</p><span>${item.userid}</span><button class="deladmin del" data-uid="1">删除</button>`
              );
              $(".adlist").append(li);
            });
          } else if (res.data.length == 0) {
            var li = $('<li">暂时没有该品牌</li>');
            $(".adlist").append(li);
          }
        }
      );
    } else {
      // 当input 为空时  重新获取列表
      // $("#brlist").empty();
      allAdmin();
      // alert(res['msg'])
    }
    // Ajax.post(
    //   {
    //     url: `admin/queryadmin`,
    //     data: {
    //       keyword: keyword
    //     }
    //   },
    //   res => {
    //     if (res["code" === 0]) {
    //       $(".adlist").empty();
    //       $.each(res.data, function(index, item) {
    //         var li = $("<li>").html(
    //           `<p>${item.username}</p><span>${item.userid}</span><button class="changeadmin">编辑</button><button class="deladmin del" data-uid="1">删除</button>`
    //         );
    //         $(".adlist").append(li);
    //       });
    //     } else {
    //       alert(res["msg"]);
    //     }
    //   }
    // );
  });
  // 添加品牌
  $("#addbrand").click(function() {
    var brandname = $("#brandnamep1").val();
    var brandpasswd = $("#brandpasswd").val();
    var repeatbrandpasswd = $("#repeatbrandpasswd").val();
    var description = $("#description1").val();
    var controller= $("#controller").val();
    var province = $("#province")
        .find("option:selected")
        .text();
    var city = $(".city")
        .find("option:selected")
        .text();
    var district = $(".district")
        .find("option:selected")
        .text();
    var geo = $("#shopgeo").val();
    /*验证密码*/
    if (brandpasswd !== repeatbrandpasswd) {
      alert("请输入相同密码");
      return false;
    }
    if (12 < brandpasswd.length || repeatbrandpasswd.length < 6) {
      alert("密码不能大于12位数且不能少于6位数");
      return false;
    }
    Ajax.add_user(
      {
        url: `admin/addbranduser`,
        elem: $("#brandimg1"),
        fdata: {
          brandname: brandname,
          brandpasswd: brandpasswd,
          controller:controller,
          province:province,
          city:city,
          district:district,
          geo:geo,
          repeatbrandpasswd: repeatbrandpasswd,
          description: description
        }
      },
      res => {
        console.log(res);
        if (res.msg === "创建成功") {
          /*重置输入*/
          $("#province").val("");
          $(".city").val("");
          $(".district").val("");
          $("#shopgeo").val("");
          $("#brandnamep1").val("");
          $("#brandpasswd").val("");
          $("#repeatbrandpasswd").val("");
          $("#description1").val("");
          $("#controller").val("");
          $("#pinpai").css("display", "none");
          /*列出所有品牌*/
           allBrand();
        } else {
          alert(res["msg"]);
        }
      }
    );
  });

  /*删除品牌*/
  $(document).on("click", ".delbrand", function() {
    // $("#isdel").css("display", "block");
    // $("#suredelshop").attr("bid", $(this).data("bid"));
    let brandid = $(this).data("bid");
    console.log(brandid);
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      console.log("你点击了确定");
      Ajax.post(
        {
          url: `admin/deletebranduser`,
          data: {
            brandid: brandid
          }
        },
        res => {
          if (res.msg === "删除成功") {
             allBrand();
          } else {
            alert("删除失败，请稍后重试。");
          }
        }
      );
    } else {
      console.log("你点击了取消");
    }
  });

  // 查询品牌
  $(".searchbrand").click(function() {
    console.log(11);
    // $('.brandlist ul').empty()

    var keyword = $(".adkeyword").val();
    console.log(keyword);
    if (keyword.trim() != "") {
      Ajax.post(
        {
          url: `admin/querybrand`,
          data: {
            keyword: keyword
          }
        },
        res => {
          $("#brlist").empty();
          if (res.data.length !== 0) {
            var data = res.data || [];
            $.each(data, function(index, item) {
              var li = $("<li></li>");
              li.html(
                ` <p id="brandname">${item.brandname}</p><span id="branddescription">${item.description}</span><img id="brandavatar" src="${Ajax.url}/${item.avatar}" alt=""><span style="
    padding: 0 0px 0 0px;
    width: 370px;
">${item.position}</span><button onclick="change()" class="changebrand" data-bid="${item.id}">编辑</button><button class="delbrand del" data-bid="${item.id}">删除</button>`
              );
              $("#brlist").append(li);
            });
          } else if (res.data.length == 0) {
            var li = $('<li">暂时没有该品牌</li>');
            $("#brlist").append(li);
          }
        }
      );
    } else if (keyword == "") {
      // 当input 为空时  重新获取列表
      $("#brlist").empty();
      allBrand();
      // alert(res['msg'])
    }
  });

  // // 查询admin
  // $(".searchadmin").click(function() {
  //   console.log(11);
  //   // $('.brandlist ul').empty()
  //
  //   var keyword = $(".adminkeyword").val();
  //   console.log(keyword);
  //   if (keyword.trim() != "") {
  //     Ajax.post(
  //       {
  //         url: `admin/queryadmin`,
  //         data: {
  //           keyword: keyword
  //         }
  //       },
  //       res => {
  //         $("#brlist").empty();
  //         if (res.data.length !== 0) {
  //           var data = res.data || [];
  //           $.each(data, function(index, item) {
  //             var li = $("<li></li>");
  //             li.html(
  //               ` <p id="brandname">${item.brandname}</p><span id="branddescription">${item.description}</span><img id="brandavatar" src="http://huahui.booksnippetshub.com:8080${item.avatar}" alt=""><button onclick="change()" class="changebrand" data-bid="${item.id}">编辑</button><button class="delbrand del" data-bid="${item.id}">删除</button>`
  //             );
  //             $("#brlist").append(li);
  //           });
  //         } else if (res.data.length == 0) {
  //           var li = $('<li">暂时没有该品牌</li>');
  //           $("#brlist").append(li);
  //         }
  //       }
  //     );
  //   } else if (keyword == "") {
  //     // 当input 为空时  重新获取列表
  //     $("#brlist").empty();
  //     allBrand();
  //     // alert(res['msg'])
  //   }
  // });

  // 获得一个品牌信息;
  $(document).on("click", ".changebrand", function(e) {
    $("#changepinpai").css("display", "block");
    let brandid = $(this).data("bid");
     var name = $(this).attr('data-name')
    // var description = $(this).attr('data-description')
    // var imgurl = $(this).attr('data-avatar')
    // console.log(name)

    Ajax.get(
      {
        url: `brand/getbrand`,
        data: { brandid: brandid }
      },
      res => {
        if (res.code === 0) {
          sessionStorage.setItem("brandid", res.data.brandid);
          $("#changepinpai #brandnamep").val(name);
          $("#changepinpai #description").val(res.data.description);
          $("#changepinpai #xmanImg").attr("src",`${Ajax.url}${res.data.avatar}`);
        }
      }
    );
  });


  //更新品牌信息
  $("#changepinpai #addbrand").click(function() {
    var brandid = sessionStorage.getItem("brandid");
    var description = $("#changepinpai #description").val();
    var img = $("#changepinpai #brandimg")[0].files[0];//上传的头像文件
    var formData = new FormData();
    formData.append("brandid",brandid);
    formData.append("description",description);
    formData.append("img",img);
    Ajax.post(
      {
        url: "brand/updatebrandadmin",
        data: formData,
        processData:false,
        async:true,
        contentType:false
      },
      res => {
        if (res.code==0){
          alert("修改成功");
          $("#changepinpai").css("display", "none");
          allBrand();
        }else {
          alert(res.msg)
        }
      }
    );
  });

  /*设置网站标题*/
  $(".titlechange").click(function() {
    var websitename = $(".websitename").val();
    Ajax.post(
      {
        url: `setting/websitename`,
        data: { name: websitename }
      },
      res => {
        if (res["msg"] === "成功") {
          $("#titlename").text(websitename);
          alert("修改成功")

        } else {
          alert("修改失败，请稍后重试。");
        }
      }
    );
  });

  /*微信提示*/
  $(".wxfirstchange").click(function() {
    var wxfirst = $(".wxfirst").val();
    Ajax.post(
        {
          url: `setting/wxfirst`,
          data: { name: wxfirst }
        },
        res => {
          if (res["msg"] === "成功") {
            alert("修改成功")
          } else {
            alert("修改失败，请稍后重试。");
          }
        }
    );
  });


  /*修改登录背景图*/
  $(".skin").click(function() {
    Ajax.add_bg(
      {
        url: `setbgimg`,
        elem: $("#pic")
      },
      res => {
        if (res["msg"] === "成功") {
          alert("修改成功");
        } else {
          alert("修改失败，请稍后重试。");
        }
      }
    );
  });

  // 运营概况数量
  Ajax.get(
    {
      url: `status/admin`
    },
    res => {
      if (res["msg"] === "成功") {
        $(".gailan>.gailanbox>.brandnum>span").text(res.data.brandcount);
        $(".gailan>.gailanbox>.shopnum>span").text(res.data.shopcount);
      }
    }
  );
});
