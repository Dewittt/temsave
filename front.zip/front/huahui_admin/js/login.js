$(document).ready(function() {
  $("#in").click(function() {
    var username = $("#name").val();
    var password = $("#password").val();
    Ajax.post(
      {
        url: `login`,
        data: {
          username: username,
          password: password
        }
      },
      res => {
        console.log(res);
        if (res["code"] === 0) {
          if (res["data"]["role"] == "admin") {
            window.location.href = "../system.html";
          }

          if (res["data"]["role"] == "brand") {
            window.location.href = "../brand.html";
          }

          if (res["data"]["role"] == "shop") {
            window.location.href = "../shop.html";
          }

          if (res["data"]["role"] == "staff") {
            window.location.href = "../staff.html";
          }

          if (res["data"]["role"] == "reporter") {
            window.location.href = "../reporter.html";
          }

          sessionStorage.setItem("loginpathname",window.location.pathname)

        } else {
          alert(res["msg"]);
        }
      }
    );
  });
  Ajax.get(
    {
      url: `bgimg`
    },
    res => {
      console.log(res);
      if (res["msg"] === "成功") {
        //查看图片地址是否需要拼接
        $(".login").css(
          "background-image",
          `url(${Ajax.url}${res.data.bgimg})`
        );
      } else {
        alert(res["msg"]);
      }
    }
  );
});
