function strtoDate(str) {

    var year = str.substr(0, 4);
    var month = str.substr(5, 2);
    var day = str.substr(8, 2);

    return new Date(year, month, day)
}

function Datetostr(date) {

    var year = date.getFullYear();
    var month = date.getMonth();
    if (month===0){
        month=12;
        year-=1;
    }
    var day = date.getDate();

    return year + '-' + month + '-' + day;
}

$(document).ready(function () {

    // 项目分析（第一张表）
    var tem1data = null;
    $("#statistics-one").click(function () {
        // var projectname = $("#projectname").text();
        // var sumprice = $("#sumprice").text();
        // var countprojectname = $("#countprojectname").text();
        var starttime = $("#test-d7").text();
        var endtime = $("#test-d8").text();
        Ajax.get(
            {
                url: `analysis/project`,
                data: {
                    starttime: starttime,
                    endtime: endtime
                }
            },
            res => {
                if (res["code"] === 0) {
                    tem1data = res["data"];
                    // var productProjectSumPriceAndCount = [
                    //   {
                    //     projectname: "project2",
                    //     sumprice: 45,
                    //     countprojectname: 1
                    //   }
                    // ];
                    // var beautyProjectSumPriceAndCount = [
                    //   {
                    //     projectname: "project3",
                    //     sumprice: 25,
                    //     countprojectname: 2
                    //   }
                    // ];
                    // var bodyProjectSumPriceAndCount = [
                    //   {
                    //     projectname: "project5",
                    //     sumprice: 25,
                    //     countprojectname: 2
                    //   }
                    // ];
                    $("#product").empty();
                    $("#beauty").empty();
                    $("#body").empty();
                    $.each(res["data"]["productmoney"], function (index, item) {
                        var div = $("<div>")
                            .html(
                                `<div class="name" id="projectname">${item.name}
        </div><div class="money" id="sumprice">${item.summoney}</div><div class="name" id="projectname">${res["data"]["productcount"][index]["name"]}
        </div><div class="shuliang" id="countprojectname">${res["data"]["productcount"][index]["sumcount"]}</div>`
                            )
                            .addClass("num");
                        div.attr("data-index1", index);
                        $("#product").append(div);
                    });
                    $.each(res["data"]["beautymoney"], function (index, item) {
                        var div = $("<div>")
                            .html(
                                ` <div class="name" id="projectname">${item.name}
        </div><div class="money" id="sumprice">${item.summoney}</div><div class="name" id="projectname">${res["data"]["beautycount"][index]["name"]}
        </div><div class="shuliang" id="countprojectname">${res["data"]["beautycount"][index]["sumcount"]}</div>`
                            )
                            .addClass("num");
                        div.attr("data-index2", index);
                        $("#beauty").append(div);
                    });
                    $.each(res["data"]["bodymoney"], function (index, item) {
                        var div = $("<div>")
                            .html(
                                ` <div class="name" id="projectname">${item.name}
        </div><div class="money" id="sumprice">${item.summoney}</div><div class="name" id="projectname">${res["data"]["bodycount"][index]["name"]}
        </div><div class="shuliang" id="countprojectname">${res["data"]["bodycount"][index]["sumcount"]}</div>`
                            )
                            .addClass("num");
                        div.attr("data-index3", index);
                        $("#body").append(div);
                    });
                }
            }
        );
    });

    $(document).on("click", "div.num", function (e) {
        var index1 = $(this).data("index1");
        var index2 = $(this).data("index2");
        var index3 = $(this).data("index3");
        if (index1 !== undefined && index1 !== tem1data["productmoney"].length - 1) {
            $("#projectdetail").css("display", "block");
            var tbody = $("#tableContent");
            tbody.empty();
            tbody.append(`<tr>
                        <th>顾客名</th>
                        <th>金额</th>
                        <th>数量</th>
                    </tr>`);
            $.each(tem1data["productmoney"][index1]["details"], function (index, item) {
                var tr = $("<tr></tr>").html(
                    `<td>${item.customer}</td>
              <td>${item.money}</td>
              <td>${item.times}</td>
             `
                );
                tbody.append(tr);
            })
        }
        if (index2 !== undefined && index2 !== tem1data["beautymoney"].length - 1) {
            $("#projectdetail").css("display", "block");
            var tbody = $("#tableContent");
            tbody.empty();
            tbody.append(`<tr>
                        <th>顾客名</th>
                        <th>金额</th>
                        <th>数量</th>
                    </tr>`);

            $.each(tem1data["beautymoney"][index2]["details"], function (index, item) {
                var tr = $("<tr></tr>").html(
                    `<td>${item.customer}</td>
              <td>${item.money}</td>
              <td>${item.times}</td>
             `
                );
                tbody.append(tr);
            })
        }
        if (index3 !== undefined && index3 !== tem1data["bodymoney"].length - 1) {
            $("#projectdetail").css("display", "block");
            var tbody = $("#tableContent");
            tbody.empty();
            tbody.append(`<tr>
                        <th>顾客名</th>
                        <th>金额</th>
                        <th>数量</th>
                    </tr>`);
            $.each(tem1data["bodymoney"][index3]["details"], function (index, item) {
                var tr = $("<tr></tr>").html(
                    `<td>${item.customer}</td>
              <td>${item.money}</td>
              <td>${item.times}</td>
             `
                );
                tbody.append(tr);
            })
        }

    });


    //   客流统计（第二张表）
    $("#statistics-two").click(function () {
        var starttime = $("#test-d5").text();
        endtime = $("#test-d6").text();
        var shopid = $("#tab-6-1 > div.title > div.left > select").val();
        Ajax.get(
            {
                url: `analysis/cuflow`,
                data: {
                    starttime: starttime,
                    endtime: endtime,
                    shopid: shopid
                }
            },
            res => {
                if (res["code"] === 0) {
                    var data = res["data"];

                    var piedata = data[3]["con"];
                    //饼图
                    var myChart = echarts.init(document.getElementById("main"));
                    option = {
                        title: {
                            text: "",
                            subtext: "",
                            x: "center"
                        },
                        tooltip: {
                            trigger: "item",
                            formatter: "{b}"
                        },
                        series: [
                            {
                                name: "",
                                type: "pie", //饼状图
                                radius: "60%", //大小
                                center: ["50%", "40%"], //显示位置
                                data: [
                                    {
                                        value: piedata[0]["con"],
                                        name: "到店1次",
                                        itemStyle: {normal: {color: "#E35406"}}
                                    },
                                    {
                                        value: piedata[1]["con"],
                                        name: "到店2次",
                                        itemStyle: {normal: {color: "#06E3E0"}}
                                    },
                                    {
                                        value: piedata[2]["con"],
                                        name: "到店3次",
                                        itemStyle: {normal: {color: "#E38806"}}
                                    },
                                    {
                                        value: piedata[3]["con"],
                                        name: "到店4次",
                                        itemStyle: {normal: {color: "#0698E3"}}
                                    },
                                    {
                                        value: piedata[4]["con"],
                                        name: "到店5次",
                                        itemStyle: {normal: {color: "#7306E3"}}
                                    }
                                ], //数据,我们ajax获取
                                itemStyle: {
                                    normal: {
                                        label: {
                                            show: true,
                                            position: "outer",
                                            fontSize: 14,
                                            // fontWeight: "bold",
                                            // align: "left",
                                            formatter: function (p) {
                                                //指示线对应文字，说明文字
                                                return p.data.name;
                                            }
                                        },
                                        color: function (params) {
                                            //自定义颜色
                                            var colorList = ["#00CD00", "#FF7F00"];
                                            return colorList[params.dataIndex];
                                        },
                                        labelLine: {
                                            //指示线状态
                                            show: true,
                                            smooth: 0.2,
                                            length: 10,
                                            length2: 20
                                        }
                                    }
                                }
                            },
                            {
                                name: "",
                                type: "pie",
                                avoidLabelOverlap: true,
                                radius: "60%", //大小
                                center: ["50%", "40%"], //显示位置
                                data: [
                                    {
                                        value: piedata[0]["con"],
                                        name: piedata[0]["百分比"],
                                        itemStyle: {normal: {color: "#E35406"}}
                                    },
                                    {
                                        value: piedata[1]["con"],
                                        name: piedata[1]["百分比"],
                                        itemStyle: {normal: {color: "#06E3E0"}}
                                    },
                                    {
                                        value: piedata[2]["con"],
                                        name: piedata[2]["百分比"],
                                        itemStyle: {normal: {color: "#E38806"}}
                                    },

                                    {
                                        value: piedata[3]["con"],
                                        name: piedata[3]["百分比"],
                                        itemStyle: {normal: {color: "#0698E3"}}
                                    },
                                    {
                                        value: piedata[4]["con"],
                                        name: piedata[4]["百分比"],
                                        itemStyle: {normal: {color: "#7306E3"}}
                                    }
                                ],
                                itemStyle: {
                                    normal: {
                                        label: {
                                            show: true,
                                            position: "inner",
                                            fontSize: 14,
                                            // fontWeight: "bold",
                                            // align: "left",
                                            formatter: function (p) {
                                                //指示线对应文字,百分比
                                                // return p.percent + "%";
                                                return p.data.name;
                                            }
                                        },
                                        color: function (params) {
                                            //自定义颜色
                                            var colorList = ["#00CD00", "#FF7F00"];
                                            return colorList[params.dataIndex];
                                        },
                                        labelLine: {
                                            //指示线状态
                                            show: true,
                                            smooth: 0.2,
                                            length: 10,
                                            length2: 20
                                        }
                                    }
                                }
                            }
                        ]
                    };
                    myChart.setOption(option);
                    $("#kefen").css("display","block");

                    var div = $("#costomerbox");
                    div.empty();
                    for (var i = 0; i < data[0]["con"].length; i++) {
                        var subdiv = $(`<div class="costomerbox-item"></div>`);
                        subdiv.append(`<div class="customertimes">
                      <div class="xuhao">${data[0]["con"][i]["排名"]}</div>
                      <div class="name">${data[0]["con"][i]["customer"]}</div>
                      <div class="numb">${data[0]["con"][i]["times"]}</div>
                      </div>`
                        );
                        if (data[1]["con"][i] !== undefined) {
                            subdiv.append(`<div class="customerprice">
                      <div class="name">${data[1]["con"][i]["customer"]}</div>
                      <div class="numb">${data[1]["con"][i]["smoney"]}</div>
                      </div>`
                            );
                        }
                        if (data[1]["con"][i] === undefined && data[2]["con"][i] !== undefined) {
                            subdiv.append(`<div class="customerprice">
                      <div class="name"></div>
                      <div class="numb"></div>
                      </div>`
                            );
                        }
                        if (data[2]["con"][i] !== undefined) {
                            subdiv.append(`<div class="customerprice">
                      <div class="name">${data[2]["con"][i]["customer"]}</div>
                      <div class="numb">${data[2]["con"][i]["smoney"]}</div>
                      </div>`
                            );
                        }
                        div.append(subdiv);
                    }
                }
            }
        );
    });

    // 经营分析（第三个表）
    var tem2data = null;
    var jingyingstarttime = null;
    var jingyingendtime = null;
    $("#bussiness").click(function () {
        var starttime = $("#test-e3").text();
        endtime = $("#test-e4").text();

        if (jingyingstarttime === null) {
            jingyingstarttime = strtoDate(starttime);
        } else {
            jingyingstarttime = strtoDate(starttime) < jingyingstarttime ? strtoDate(starttime) : jingyingstarttime;
        }
        if (jingyingendtime === null) {
            jingyingendtime = strtoDate(endtime);
        } else {
            jingyingendtime = strtoDate(endtime) > jingyingendtime ? strtoDate(endtime) : jingyingendtime;
        }
        Ajax.get(
            {
                url: `analysis/management`,
                data: {
                    starttime: starttime,
                    endtime: endtime
                }
            },
            res => {
                if (res["code"] === 0) {
                    var data1 = res["data"]["managementanalysis"];
                    var div = $(`<div class="main" id="jingyingmain">
                                <div class="timeInterval1">${starttime+"/"+endtime}</div>
                                    <table id="jingyingtable">
                                        <thead class="biaotou one">
                                            <tr>
                                                <th rowspan="2" class="tablehead">经营分析表</th>
                                            </tr>
                                            <tr class="tablebot">
                                                <th id="money">金额</th>
                                                <th id="num">数量</th>
                                            </tr>
                                        </thead>
                                    </table>
                                    <div id="jingyingdata"></div>
                                    <table class="xiangqing">
                                         <!--实操类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" id="categoryname">${data1[0]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][2]["category2"]}</td>
                                            <td class="money"id="sumprice">${data1[0]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][1]["category2"]}</td>
                                            <td class="money"id="sumprice">${data1[0]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[0]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td  class="zongji"
                                            id="category2name">总计</td>
                                            <td class="zongji" id="sumprice">${data1[0]["con"][3]["summoney"]}</td>
                                            <td class="zongji" id="sumcount">${data1[0]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--产品类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" class="chanpin">${data1[1]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji chanpin" id="category2name">总计</td>
                                            <td class="zongji chanpin" id="sumprice">${data1[1]["con"][3]["summoney"]}</td>
                                            <td class="zongji chanpin" id="sumcount">${data1[1]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--现金类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" class="xianjin">${data1[2]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji xianjin" id="category2name">总计</td>
                                            <td class="zongji xianjin" id="sumprice">${data1[2]["con"][3]["summoney"]}</td>
                                            <td class="zongji xianjin" id="sumcount">${data1[2]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--实耗类一-->
                                        <thead class="shicao shihaolei-one">
                                        <tr>
                                            <th rowspan="6" class="shihaolei">${data1[3]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][3]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][3]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][3]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][4]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][4]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][4]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji shihao" id="category2name">总计</td>
                                            <td class="zongji shihao" id="sumprice">${data1[3]["con"][5]["summoney"]}</td>
                                            <td class="zongji shihao" id="sumcount">${data1[3]["con"][5]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--实耗类二-->
                                        <thead class="shicao shihaolei-two">
                                        <tr>
                                            <th rowspan="3">${data1[4]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[4]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[4]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[4]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[4]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[4]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[4]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji" id="category2name">总计</td>
                                            <td class="zongji" id="sumprice">${data1[4]["con"][2]["summoney"]}</td>
                                            <td class="zongji" id="sumcount">${data1[4]["con"][2]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        </table>
                                        <!--人头客流-->
                                        <table class="keliu">
                                    <thead class="biaotou">
                                        <tr>
                                            <th rowspan="2" class="tablehead">人头及客流</th>
                                            <th colspan="1" class="people one">人头</th>
                                            <th colspan="1" class="customer">客流</th>
                                        </tr>
                                        <tr class="tablebot">
                                            <th id="jingyingRentou" class="customer one">${res["data"]["tablefooter"]["headcount"]}</th>
                                            <th id="jingyingKeliu" class="customer">${res["data"]["tablefooter"]["humantraffic"]}</th>
                                        </tr>
                                    </thead>
                                </table>
                                <table class="danjia">
                                    <tr>
                                        <th>平均客单价</th>
                                        <th id="kedanJia" class="price">${res["data"]["tablefooter"]["averageprice"]}</th>
                                    </tr>
                                     </table>
                                </div>`);
                    $("#tab-6-5 > div.mainbox > div").append(div);
                }
            });
        Ajax.get(
            {
                url: `analysis/management`,
                data: {
                    starttime: Datetostr(jingyingstarttime),
                    endtime: Datetostr(jingyingendtime)
                }
            },
            res => {
                if (res["code"] === 0) {
                    var text = Datetostr(jingyingstarttime)+"/"+Datetostr(jingyingendtime);
                    $("#timeInterval1").text(text);
                    tem2data = res["data"]["managementanalysis"];
                    var data = res["data"]["managementanalysis"];


                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.mingcheng").text(data[0]["con"][2]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.money").text(data[0]["con"][2]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.num").text(data[0]["con"][2]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.mingcheng").text(data[0]["con"][1]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.money").text(data[0]["con"][1]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.num").text(data[0]["con"][1]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.mingcheng").text(data[0]["con"][0]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.money").text(data[0]["con"][0]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.num").text(data[0]["con"][0]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[0]["con"][3]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[0]["con"][3]["sumcount"]);

                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.mingcheng").text(data[1]["con"][1]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.money").text(data[1]["con"][1]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.num").text(data[1]["con"][1]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.mingcheng").text(data[1]["con"][2]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.money").text(data[1]["con"][2]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.num").text(data[1]["con"][2]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.mingcheng").text(data[1]["con"][0]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.money").text(data[1]["con"][0]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.num").text(data[1]["con"][0]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[1]["con"][3]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[1]["con"][3]["sumcount"]);

                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.mingcheng").text(data[2]["con"][2]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.money").text(data[2]["con"][2]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.num").text(data[2]["con"][2]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.mingcheng").text(data[2]["con"][0]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.money").text(data[2]["con"][0]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.num").text(data[2]["con"][0]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.mingcheng").text(data[2]["con"][1]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.money").text(data[2]["con"][1]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.num").text(data[2]["con"][1]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[2]["con"][3]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[2]["con"][3]["sumcount"]);

                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.mingcheng").text(data[3]["con"][1]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.money").text(data[3]["con"][1]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.num").text(data[3]["con"][1]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.mingcheng").text(data[3]["con"][2]["category2"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.money").text(data[3]["con"][2]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.num").text(data[3]["con"][2]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(3) > td.money").text(data[3]["con"][3]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(3) > td.num").text(data[3]["con"][3]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(4) > td.money").text(data[3]["con"][0]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(4) > td.num").text(data[3]["con"][0]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(5) > td.money").text(data[3]["con"][4]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(5) > td.num").text(data[3]["con"][4]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(6) > td.zongji:nth-child(2)").text(data[3]["con"][5]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(6) > td.zongji:nth-child(3)").text(data[3]["con"][5]["sumcount"]);

                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(1) > td.money").text(data[4]["con"][0]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(1) > td.num").text(data[4]["con"][0]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(2) > td.money").text(data[4]["con"][1]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(2) > td.num").text(data[4]["con"][1]["sumcount"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(3) > td.zongji:nth-child(2)").text(data[4]["con"][2]["summoney"]);
                    $("#jingyingmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(3) > td.zongji:nth-child(3)").text(data[4]["con"][2]["sumcount"]);

                    $("#jingyingmain:nth-child(1) > table.keliu > thead > tr.tablebot > th.customer.one").text(res["data"]["tablefooter"]["headcount"]);
                    $("#jingyingmain:nth-child(1) > table.keliu > thead > tr.tablebot > th:nth-child(2)").text(res["data"]["tablefooter"]["humantraffic"]);
                    $("#jingyingmain:nth-child(1) > table.danjia > tbody > tr > th.price").text(res["data"]["tablefooter"]["averageprice"]);
                }
            });
    });

    //经营分析表的detail
    function detail() {
        $("#analydetail > div > div.infor > table > tbody").empty();
        var i = $(this).parent().data("hindex");
        var j = $(this).data("tindex");
        if (j === undefined) {
            return;
        }
        var data = tem2data[i]["con"][j]["details"];
        $("#analydetail > div > div.infor > table > tbody").append(`<tr>
                            <th>顾客名</th>
                            <th>金额</th>
                            <th>数量</th>
                        </tr>`);
        for (var ii = 0; ii < data.length; ii++) {
            $("#analydetail > div > div.infor > table > tbody").append(`
                <tr>
                    <td>${data[ii].customer}</td>
                    <td>${data[ii].money}</td>
                    <td>${data[ii].times}</td>
                    </tr>
            `);
        }
        $("#analydetail").css("display", "block");
    }

    $(document).on("click", "#jingyingmain:nth-child(1)>table > thead > tr", detail
    );
    $(document).on("click", "#guwenmain:nth-child(1) > table > thead > tr", detail
    );
    $(document).on("click", "#jishimain:nth-child(1)>table > thead > tr", detail
    );

    //技师分析表
    var jishistarttime=null;
    var jishiendtime=null;
    $("#searchBeautician").click(function () {
        var beauticianName = $(
            "#tab-6-4 > div.title > div > input[type=text]"
        ).val();
        var starttime = $("#test-e1").text();
        endtime = $("#test-e2").text();
        if (beauticianName === "" || beauticianName === undefined) {
            alert("请输入技师名字再查询");
        } else {
            if (jishistarttime === null) {
                jishistarttime = strtoDate(starttime);
            } else {
                jishistarttime = strtoDate(starttime) < jishistarttime ? strtoDate(starttime) : jishistarttime;
            }
            if (jishiendtime === null) {
                jishiendtime = strtoDate(endtime);
            } else {
                jishiendtime = strtoDate(endtime) > jishiendtime ? strtoDate(endtime) : jishiendtime;
            }
            Ajax.get(
                {
                    url: `analysis/beauticiant`,
                    data: {
                        starttime: starttime,
                        endtime: endtime,
                        beauticianname: beauticianName
                    }
                },
                res => {
                    if (res["code"] === 0) {
                        var data1 = res["data"]["managementanalysis"];
                        var div = $(`<div class="main" id="jishimain"> <div class="timeInterval1">${starttime+"/"+endtime}</div>
                                    <table id="jingyingtable">
                                        <thead class="biaotou one">
                                            <tr>
                                                <th rowspan="2" class="tablehead">技师分析表</th>
                                            </tr>
                                            <tr class="tablebot">
                                                <th id="money">金额</th>
                                                <th id="num">数量</th>
                                            </tr>
                                        </thead>
                                    </table>
                                    <div id="jingyingdata"></div>
                                    <table class="xiangqing">
                                         <!--实操类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" id="categoryname">${data1[0]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][2]["category2"]}</td>
                                            <td class="money"id="sumprice">${data1[0]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][1]["category2"]}</td>
                                            <td class="money"id="sumprice">${data1[0]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[0]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td  class="zongji"
                                            id="category2name">总计</td>
                                            <td class="zongji" id="sumprice">${data1[0]["con"][3]["summoney"]}</td>
                                            <td class="zongji" id="sumcount">${data1[0]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--产品类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" class="chanpin">${data1[1]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji chanpin" id="category2name">总计</td>
                                            <td class="zongji chanpin" id="sumprice">${data1[1]["con"][3]["summoney"]}</td>
                                            <td class="zongji chanpin" id="sumcount">${data1[1]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--现金类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" class="xianjin">${data1[2]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji xianjin" id="category2name">总计</td>
                                            <td class="zongji xianjin" id="sumprice">${data1[2]["con"][3]["summoney"]}</td>
                                            <td class="zongji xianjin" id="sumcount">${data1[2]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--实耗类一-->
                                        <thead class="shicao shihaolei-one">
                                        <tr>
                                            <th rowspan="6" class="shihaolei">${data1[3]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][3]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][3]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][3]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][4]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][4]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][4]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji shihao" id="category2name">总计</td>
                                            <td class="zongji shihao" id="sumprice">${data1[3]["con"][5]["summoney"]}</td>
                                            <td class="zongji shihao" id="sumcount">${data1[3]["con"][5]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--实耗类二-->
                                        <thead class="shicao shihaolei-two">
                                        <tr>
                                            <th rowspan="3">${data1[4]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[4]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[4]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[4]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[4]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[4]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[4]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji" id="category2name">总计</td>
                                            <td class="zongji" id="sumprice">${data1[4]["con"][2]["summoney"]}</td>
                                            <td class="zongji" id="sumcount">${data1[4]["con"][2]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        </table>
                                        <!--人头客流-->
                                        <table class="keliu">
                                    <thead class="biaotou">
                                        <tr>
                                            <th rowspan="2" class="tablehead">人头及客流</th>
                                            <th colspan="1" class="people one">人头</th>
                                            <th colspan="1" class="customer">客流</th>
                                        </tr>
                                        <tr class="tablebot">
                                            <th id="jingyingRentou" class="customer one">${res["data"]["tablefooter"]["headcount"]}</th>
                                            <th id="jingyingKeliu" class="customer">${res["data"]["tablefooter"]["humantraffic"]}</th>
                                        </tr>
                                    </thead>
                                </table>
                                <table class="danjia">
                                    <tr>
                                        <th>平均客单价</th>
                                        <th id="kedanJia" class="price">${res["data"]["tablefooter"]["averageprice"]}</th>
                                    </tr>
                                     </table>
                                </div>`);
                        $("#tab-6-4 > div.mainbox > div").append(div);
                    }
                });
            Ajax.get(
                {
                    url: `analysis/beauticiant`,
                    data: {
                        starttime: Datetostr(jishistarttime),
                        endtime: Datetostr(jishiendtime),
                        beauticianname: beauticianName
                    }
                },
                res => {
                    if (res["code"] === 0) {
                        var text = Datetostr(jishistarttime)+"/"+Datetostr(jishiendtime);
                        $("#timeInterval3").text(text);
                        tem2data = res["data"]["managementanalysis"];
                        var data = res["data"]["managementanalysis"];


                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.mingcheng").text(data[0]["con"][2]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.money").text(data[0]["con"][2]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.num").text(data[0]["con"][2]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.mingcheng").text(data[0]["con"][1]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.money").text(data[0]["con"][1]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.num").text(data[0]["con"][1]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.mingcheng").text(data[0]["con"][0]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.money").text(data[0]["con"][0]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.num").text(data[0]["con"][0]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[0]["con"][3]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[0]["con"][3]["sumcount"]);

                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.mingcheng").text(data[1]["con"][1]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.money").text(data[1]["con"][1]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.num").text(data[1]["con"][1]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.mingcheng").text(data[1]["con"][2]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.money").text(data[1]["con"][2]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.num").text(data[1]["con"][2]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.mingcheng").text(data[1]["con"][0]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.money").text(data[1]["con"][0]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.num").text(data[1]["con"][0]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[1]["con"][3]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[1]["con"][3]["sumcount"]);

                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.mingcheng").text(data[2]["con"][2]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.money").text(data[2]["con"][2]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.num").text(data[2]["con"][2]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.mingcheng").text(data[2]["con"][0]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.money").text(data[2]["con"][0]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.num").text(data[2]["con"][0]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.mingcheng").text(data[2]["con"][1]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.money").text(data[2]["con"][1]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.num").text(data[2]["con"][1]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[2]["con"][3]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[2]["con"][3]["sumcount"]);

                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.mingcheng").text(data[3]["con"][1]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.money").text(data[3]["con"][1]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.num").text(data[3]["con"][1]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.mingcheng").text(data[3]["con"][2]["category2"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.money").text(data[3]["con"][2]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.num").text(data[3]["con"][2]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(3) > td.money").text(data[3]["con"][3]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(3) > td.num").text(data[3]["con"][3]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(4) > td.money").text(data[3]["con"][0]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(4) > td.num").text(data[3]["con"][0]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(5) > td.money").text(data[3]["con"][4]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(5) > td.num").text(data[3]["con"][4]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(6) > td.zongji:nth-child(2)").text(data[3]["con"][5]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(6) > td.zongji:nth-child(3)").text(data[3]["con"][5]["sumcount"]);

                        $("#jishimain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(1) > td.money").text(data[4]["con"][0]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(1) > td.num").text(data[4]["con"][0]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(2) > td.money").text(data[4]["con"][1]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(2) > td.num").text(data[4]["con"][1]["sumcount"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(3) > td.zongji:nth-child(2)").text(data[4]["con"][2]["summoney"]);
                        $("#jishimain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(3) > td.zongji:nth-child(3)").text(data[4]["con"][2]["sumcount"]);

                        $("#jishimain:nth-child(1) > table.keliu > thead > tr.tablebot > th.customer.one").text(res["data"]["tablefooter"]["headcount"]);
                        $("#jishimain:nth-child(1) > table.keliu > thead > tr.tablebot > th:nth-child(2)").text(res["data"]["tablefooter"]["humantraffic"]);
                        $("#jishimain:nth-child(1) > table.danjia > tbody > tr > th.price").text(res["data"]["tablefooter"]["averageprice"]);
                    }
                });
        }
    });

    //顾问分析表
    var guwenstarttime = null;
    var guwenendtime = null;
    $("#searchConsultant").click(function () {
        var consultantName = $(
            "#tab-6-6 > div.title > div > input[type=text]"
        ).val();
        var starttime = $("#test-e13").text();
        endtime = $("#test-e14").text();
        if (consultantName === "" || consultantName === undefined) {
            alert("请输入顾问名字再查询");
        } else {
            if (guwenstarttime === null) {
                guwenstarttime = strtoDate(starttime);
            } else {
                guwenstarttime = strtoDate(starttime) < guwenstarttime ? strtoDate(starttime) : guwenstarttime;
            }
            if (guwenendtime === null) {
                guwenendtime = strtoDate(endtime);
            } else {
                guwenendtime = strtoDate(endtime) > guwenendtime ? strtoDate(endtime) : guwenendtime;
            }
            Ajax.get(
                {
                    url: `analysis/consultant`,
                    data: {
                        starttime: starttime,
                        endtime: endtime,
                        consultantname: consultantName
                    }
                },
                res => {
                    if (res["code"] === 0) {
                        var data1 = res["data"]["managementanalysis"];
                        var div = $(`<div class="main" id="guwenmain"> <div class="timeInterval1">${starttime+"/"+endtime}</div>
                                    <table id="guwentable">
                                        <thead class="biaotou one">
                                            <tr>
                                                <th rowspan="2" class="tablehead">顾问分析表</th>
                                            </tr>
                                            <tr class="tablebot">
                                                <th id="money">金额</th>
                                                <th id="num">数量</th>
                                            </tr>
                                        </thead>
                                    </table>
                                    <div id="jingyingdata"></div>
                                    <table class="xiangqing">
                                         <!--实操类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" id="categoryname">${data1[0]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][2]["category2"]}</td>
                                            <td class="money"id="sumprice">${data1[0]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][1]["category2"]}</td>
                                            <td class="money"id="sumprice">${data1[0]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[0]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[0]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[0]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td  class="zongji"
                                            id="category2name">总计</td>
                                            <td class="zongji" id="sumprice">${data1[0]["con"][3]["summoney"]}</td>
                                            <td class="zongji" id="sumcount">${data1[0]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--产品类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" class="chanpin">${data1[1]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[1]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[1]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[1]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji chanpin" id="category2name">总计</td>
                                            <td class="zongji chanpin" id="sumprice">${data1[1]["con"][3]["summoney"]}</td>
                                            <td class="zongji chanpin" id="sumcount">${data1[1]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--现金类-->
                                        <thead class="shicao">
                                        <tr>
                                            <th rowspan="4" class="xianjin">${data1[2]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[2]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[2]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[2]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji xianjin" id="category2name">总计</td>
                                            <td class="zongji xianjin" id="sumprice">${data1[2]["con"][3]["summoney"]}</td>
                                            <td class="zongji xianjin" id="sumcount">${data1[2]["con"][3]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--实耗类一-->
                                        <thead class="shicao shihaolei-one">
                                        <tr>
                                            <th rowspan="6" class="shihaolei">${data1[3]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][2]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][2]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][2]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][3]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][3]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][3]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[3]["con"][4]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[3]["con"][4]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[3]["con"][4]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji shihao" id="category2name">总计</td>
                                            <td class="zongji shihao" id="sumprice">${data1[3]["con"][5]["summoney"]}</td>
                                            <td class="zongji shihao" id="sumcount">${data1[3]["con"][5]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        <!--实耗类二-->
                                        <thead class="shicao shihaolei-two">
                                        <tr>
                                            <th rowspan="3">${data1[4]["type"]}</th>
                                            <td class="mingcheng" id="category2name">${data1[4]["con"][0]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[4]["con"][0]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[4]["con"][0]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="mingcheng" id="category2name">${data1[4]["con"][1]["category2"]}</td>
                                            <td class="money" id="sumprice">${data1[4]["con"][1]["summoney"]}</td>
                                            <td class="num" id="sumcount">${data1[4]["con"][1]["sumcount"]}</td>
                                        </tr>
                                        <tr>
                                            <td class="zongji" id="category2name">总计</td>
                                            <td class="zongji" id="sumprice">${data1[4]["con"][2]["summoney"]}</td>
                                            <td class="zongji" id="sumcount">${data1[4]["con"][2]["sumcount"]}</td>
                                        </tr>
                                    </thead>
                                        </table>
                                        <!--人头客流-->
                                        <table class="keliu">
                                    <thead class="biaotou">
                                        <tr>
                                            <th rowspan="2" class="tablehead">人头及客流</th>
                                            <th colspan="1" class="people one">人头</th>
                                            <th colspan="1" class="customer">客流</th>
                                        </tr>
                                        <tr class="tablebot">
                                            <th id="jingyingRentou" class="customer one">${res["data"]["tablefooter"]["headcount"]}</th>
                                            <th id="jingyingKeliu" class="customer">${res["data"]["tablefooter"]["humantraffic"]}</th>
                                        </tr>
                                    </thead>
                                </table>
                                <table class="danjia">
                                    <tr>
                                        <th>平均客单价</th>
                                        <th id="kedanJia" class="price">${res["data"]["tablefooter"]["averageprice"]}</th>
                                    </tr>
                                     </table>
                                </div>`);
                        $("#tab-6-6 > div.mainbox > div").append(div);
                    }
                });
            Ajax.get(
                {
                    url: `analysis/consultant`,
                    data: {
                        starttime: Datetostr(guwenstarttime),
                        endtime: Datetostr(guwenendtime),
                        consultantname: consultantName
                    }
                },
                res => {
                    if (res["code"] === 0) {
                        var text = Datetostr(guwenstarttime)+"/"+Datetostr(guwenendtime);
                        $("#timeInterval2").text(text);
                        tem2data = res["data"]["managementanalysis"];
                        var data = res["data"]["managementanalysis"];


                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.mingcheng").text(data[0]["con"][2]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.money").text(data[0]["con"][2]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(1) > td.num").text(data[0]["con"][2]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.mingcheng").text(data[0]["con"][1]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.money").text(data[0]["con"][1]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(2) > td.num").text(data[0]["con"][1]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.mingcheng").text(data[0]["con"][0]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.money").text(data[0]["con"][0]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(3) > td.num").text(data[0]["con"][0]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[0]["con"][3]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(1) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[0]["con"][3]["sumcount"]);

                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.mingcheng").text(data[1]["con"][1]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.money").text(data[1]["con"][1]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(1) > td.num").text(data[1]["con"][1]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.mingcheng").text(data[1]["con"][2]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.money").text(data[1]["con"][2]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(2) > td.num").text(data[1]["con"][2]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.mingcheng").text(data[1]["con"][0]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.money").text(data[1]["con"][0]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(3) > td.num").text(data[1]["con"][0]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[1]["con"][3]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(2) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[1]["con"][3]["sumcount"]);

                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.mingcheng").text(data[2]["con"][2]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.money").text(data[2]["con"][2]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(1) > td.num").text(data[2]["con"][2]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.mingcheng").text(data[2]["con"][0]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.money").text(data[2]["con"][0]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(2) > td.num").text(data[2]["con"][0]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.mingcheng").text(data[2]["con"][1]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.money").text(data[2]["con"][1]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(3) > td.num").text(data[2]["con"][1]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(4) > td.zongji:nth-child(2)").text(data[2]["con"][3]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(3) > tr:nth-child(4) > td.zongji:nth-child(3)").text(data[2]["con"][3]["sumcount"]);

                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.mingcheng").text(data[3]["con"][1]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.money").text(data[3]["con"][1]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(1) > td.num").text(data[3]["con"][1]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.mingcheng").text(data[3]["con"][2]["category2"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.money").text(data[3]["con"][2]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(2) > td.num").text(data[3]["con"][2]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(3) > td.money").text(data[3]["con"][3]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(3) > td.num").text(data[3]["con"][3]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(4) > td.money").text(data[3]["con"][0]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(4) > td.num").text(data[3]["con"][0]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(5) > td.money").text(data[3]["con"][4]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(5) > td.num").text(data[3]["con"][4]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(6) > td.zongji:nth-child(2)").text(data[3]["con"][5]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(4) > tr:nth-child(6) > td.zongji:nth-child(3)").text(data[3]["con"][5]["sumcount"]);

                        $("#guwenmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(1) > td.money").text(data[4]["con"][0]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(1) > td.num").text(data[4]["con"][0]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(2) > td.money").text(data[4]["con"][1]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(2) > td.num").text(data[4]["con"][1]["sumcount"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(3) > td.zongji:nth-child(2)").text(data[4]["con"][2]["summoney"]);
                        $("#guwenmain:nth-child(1) > table > thead:nth-child(5) > tr:nth-child(3) > td.zongji:nth-child(3)").text(data[4]["con"][2]["sumcount"]);

                        $("#guwenmain:nth-child(1) > table.keliu > thead > tr.tablebot > th.customer.one").text(res["data"]["tablefooter"]["headcount"]);
                        $("#guwenmain:nth-child(1) > table.keliu > thead > tr.tablebot > th:nth-child(2)").text(res["data"]["tablefooter"]["humantraffic"]);
                        $("#guwenmain:nth-child(1) > table.danjia > tbody > tr > th.price").text(res["data"]["tablefooter"]["averageprice"]);
                    }
                });
        }
    });

    $("#beauticianTable").click(function () {
        var beautician = $("#beauticianName2").val();
        var fenxi = $("#beauticianCatagory").val();
        var starttime = $("#test-e11").text();
        endtime = $("#test-e12").text();
        Ajax.get(
            {
                url: `analysis/beauticianttable`,
                data: {
                    staffname: beautician,
                    starttime: starttime,
                    endtime: endtime,
                    fenxi: fenxi
                }
            },
            res => {
                if (res["code"] === 0) {
                    var data = res["data"];
                    var table = $("#tab-6-7 > div.main > div > div.detail > table");
                    table.empty();
                    for (var i = 0; i < data.length; i++) {
                        var subdata = data[i]["con"];
                        var tbody = $("<tbody></tbody>");
                        var len = subdata.length;
                        for (var j = 0; j < len; j++) {
                            if (j === 0) {
                                tbody.append(`<tr>
                                            <td rowspan="${len}" class="custname">${data[i]["name"]}</td>
                                            <td class="custdata">${subdata[j]["time"]}</td>
                                            <td class="projectname">${subdata[j]["projectname"]}</td>
                                            <td class="custmoney">${subdata[j]["summoney"]}</td>
                                            <td class="number">${subdata[j]["count"]}</td>
                                            <td class="zfx">${subdata[j]["allocate"]}</td>
                                            <td class="hand">${subdata[j]["sumhand"]}</td>
                                        </tr>`);
                            } else {
                                tbody.append(`<tr>
                                            <td class="custdata">${subdata[j]["time"]}</td>
                                            <td class="projectname">${subdata[j]["projectname"]}</td>
                                            <td class="custmoney">${subdata[j]["summoney"]}</td>
                                            <td class="number">${subdata[j]["count"]}</td>
                                            <td class="zfx">${subdata[j]["allocate"]}</td>
                                            <td class="hand">${subdata[j]["sumhand"]}</td>
                                        </tr>`);
                            }
                        }
                        table.append(tbody);
                    }
                }
            }
        );
    });

    $("#customerConsumption").click(function () {
        var starttime = $("#test-d9").text();
        endtime = $("#test-d10").text();
        var customer = $("#customerName").val();
        var category = $("#customerSearchCategory")
            .find("option:selected")
            .text();
        if (customer === "" || customer === undefined) {
            alert("请输入顾客名字");
        } else {
            Ajax.get(
                {
                    url: `analysis/customer`,
                    data: {
                        customer: customer,
                        starttime: starttime,
                        endtime: endtime,
                        handorcash: category
                    }
                },
                res => {
                    if (res.code === 0) {
                        var data = res["data"]["客户信息"];
                        var table = $("#tab-6-3 > div.main > div > div.detail > table");
                        table.empty();
                        var tbody = $("<tbody></tbody>");
                        var i = 0;
                        for (; i < data.length - 1; i++) {
                            console.log(i);
                            console.log(data[i]["projectname"]);
                            if (i === 0) {
                                tbody.append(`<tr>
                                            <td rowspan="${data.length}" class="custname">${data[i]["customer"]}</td>
                                            <td rowspan="${data.length}" class="custactive">${data[i]["status"]}</td>
                                            <td class="custdata">${data[i]["createtime"]}</td>
                                            <td class="projectname">${data[i]["projectname"]}</td>
                                            <td class="custmoney">${data[i]["money"]}</td>
                                            <td class="number">${data[i]["times"]}</td>
                                        </tr>`);
                            } else {
                                tbody.append(`<tr>
                                            <td class="custdata">${data[i]["createtime"]}</td>
                                            <td class="projectname">${data[i]["projectname"]}</td>
                                            <td class="custmoney">${data[i]["money"]}</td>
                                            <td class="number">${data[i]["times"]}</td>
                                        </tr>`);
                            }
                        }
                        table.append(tbody);
                        $("#tab-6-3 > div.main > div > div.total > span.totalmoney").text(
                            data[i]["money"]
                        );
                        $("#tab-6-3 > div.main > div > div.total > span.totalnum").text(
                            data[i]["times"]
                        );
                        $("#tab-6-3 > div.main > div > div.distance > p > span").text(
                            res["data"]["距离上次"]
                        );
                    }
                }
            );
        }
    });
});
/*</tr><tr><td class="mingcheng" id="category2name">${item.category2name}</td><td class="money" id="sumprice">${item.sumprice}</td><td class="num" id="sumcount">${item.sumcount}</td></tr><tr><td class="mingcheng" id="category2name">${item.category2name}</td><td class="money" id="sumprice">${item.sumprice}</td><td class="num" id="sumcount">${item.sumcount}</td></tr><tr><td  class="zongji"id="category2name">${item.category2name}</td><td class="zongji" id="sumprice">${item.sumprice}</td><td class="zongji" id="sumcount">${item.sumcount}</td></tr>*/
