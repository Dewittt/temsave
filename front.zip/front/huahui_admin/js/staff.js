var allstaff = null;

$(document).ready(function() {
  $("#submitbillsheetselect").click(function() {
    var fileSerialNumberinput = $("#fileSerialNumberinput").val();
    var billsheets = $("#billsheets").val();
    Ajax.post(
        {
          url: `settlement/importexceldata`,
          data: {
            fileSerialNumber: fileSerialNumberinput,
            sheetNames: billsheets
          }
        },
        res => {
          $("#billsheetselect").css("display", "none");
          alert(res.msg);
        }
    );
  });

  $("#closebillsheetselect").click(function() {
    var fileSerialNumberinput = $("#fileSerialNumberinput").val();

    Ajax.post(
        {
          url: `settlement/cancelimport`,
          data: {
            fileSerialNumberinput: fileSerialNumberinput
          }
        },
        res => {
          //pass
        }
    );
  });

  $("#submitbill").click(function() {
    console.log("bill upload");
    Ajax.upload_billfile(
        {
          url: `settlement/updloadexcel`,
          elem: $("#billfile")
        },
        res => {
          $("#billsheetselect").css("display", "block");
          var data = res.data;
          console.log(res);
          $("#fileSerialNumberinput").val(data["fileSerialNumber"]);

          $("#billsheets").empty();

          $.each(data["sheetNames"], function(index, item) {
            $("#billsheets").append(`<option value="${item}">${item}</option>`);
          });
        }
    );
  });
});

$(document).ready(function() {

  var change = sessionStorage.getItem("change");
  if (change!==undefined&&change!==null){
    $("#returnbrand").css("display","inline");
  }

  //返回公司权限
  $("#returnbrand").click(function () {
    Ajax.get(
        {
          url: `brand/tobrand`
        },
        res => {
          if (res.code===0) {
              sessionStorage.removeItem("change");
            window.location.href = "./brand.html";
          }
        }
    );
  });

  allStaff();

  // 列出所有reporter
  function allStaff(){
    $("#entry-clerk").empty();

    Ajax.get({
      url: `shop/reporter/all`
    },res=>{
      if (res["code"]==0){
        $.each(res["data"], function (index, item) {
          $("#entry-clerk").append(`<li style="margin-bottom: 5px"><span class="entryname">${item.name}</span><button class="delreporter" data-reporterid="${item.staffid}" >删除</button></li>`)
        });
      }
    });

    function allStaff(pagenum){

      Ajax.get(
          {
            url: `staff/allstaff`,
            data:{
              showdel: true,
              pagenum:pagenum
            }
          },
          res => {
            if (res["msg"] === "成功") {
              var ul = $("<ul>");
              var data = res["data"];
              allstaff = data;
              $.each(data, function(index, item) {
                var li = $("<li></li>");
                li.html(
                    ` <span class="name">${!item.del?item.name:item.name+"<span style='color: #ff0000;'>[已删除]</span>"}</span><span class="sex">${
                        item.male === 0 ? "男" : "女"
                    }</span><span class="month"><span class="dateInput" type="text" id="test-n7">${
                        item.birthday
                    }</span></span><span class="zhiwei">${
                        item.employment===1?"在职":"离职"
                    }</span><span class="minzu">汉族</span><span class="zhengzhi">${
                        item.party
                    }</span><span class="shenti">${
                        item.healthy
                    }</span><span class="jiguan">${
                        item.nativeplace
                    }</span><span class="add">${item.address}</span><span class="tel">${
                        item.phone
                    }</span><span class="tel">${
                        item.emergencyphone
                    }</span><span>${!item.del?'<button data-staffid="'+item.id+'" class="editstaff">编辑</button>':'<button data-staffid="'+item.id+'" class="nonebtn"> </button>'}
                    ${!item.del?'<button class="btnstaff del" data-staffid="'+item.id+'">删除</button>':'<button data-staffid="'+item.id+'" class="restorestaff">恢复</button>'}
                    </span>`
                );
                $(ul).append(li);
              });
              $(".stafflist").empty()
              $(".stafflist").append(ul);
              $('#staffpageTool').empty();

              var p = new Paging();
              p.init({
                target: '#staffpageTool',
                pagesize: res["pageinfo"]["pagessize"],
                count: res["pageinfo"]["count"],
                current: res["pageinfo"]["current"],
                callback:function (pagecount) {
                  allStaff(pagecount)
                }
              });
            }
          }
      );
    }

    allStaff(1)
  }



  // 删除staff
  $(document).on("click", ".btnstaff", function(e) {
    var staffid = $(this).data("staffid");
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      Ajax.post(
        {
          url: `staff/deletestaff`,
          data: {
            staffid: staffid
          }
        },
        res => {
          if (res.code === 0) {
            alert("删除成功");
            allStaff();
          }
        }
      );
    }
  });

  // 恢复staff
  $(document).on("click", ".restorestaff", function(e) {
    var staffid = $(this).data("staffid");
    var operat = confirm("确定恢复吗？");
    if (operat == true) {
      Ajax.post(
          {
            url: `staff/restorestaff`,
            data: {
              staffid: staffid
            }
          },
          res => {
            if (res.code === 0) {
              alert("恢复成功");
              allStaff();
            }
          }
      );
    }
  });

  /*删除reporter*/
  $(document).on("click", ".delreporter", function(e) {
    var userid = $(this).data("reporterid");
    var operat = confirm("确定删除吗？");
    if (operat == true) {
      console.log("你点击了确定");
      Ajax.post(
          {
            url: `shop/reporter/delete`,
            data: {
              staffid: userid
            }
          },
          res => {

            if (res.code==0){
              alert("删除成功");

            } else {
              alert(res["msg"]);
            }
            allStaff();
          }
      );
    } else {
      console.log("你点击了取消");
    }
  });

  $(".family .suredit").click(function () {
    if ($("#editpasswd").val()!=$("#repeateditpasswd").val()){
      alert("密码不一致");
      return;
    }
    var passwd = $("#editpasswd").val();
    if (passwd.length<6&&passwd.length!=0){
      alert("密码应该大于等于6位");
      return;
    }
    var growth=$("#editgrowth").val();
    var staffid = sessionStorage.getItem("staffid");
    var username = $("#editusername").val();
    var male = $("#editmale")
        .find("option:selected")
        .text();

    male === "男" ? (male = 0) : (male = 1);
    var birthday = $("#test-e6").text();
    var nation = $("#editnation").val();
    var party = $("#editparty")
        .find("option:selected")
        .text();
    var healthy = $("#edithealthy")
        .find("option:selected")
        .text();
    var nativeplace = $("#editnativeplace").val();
    var address = $("#editaddress").val();
    var phone = $("#editphone").val();
    var emergencyphone = $("#editemergencyphone").val();
    var p1name = $("#editp1name").val();
    var p1male = $("#editp1male")
        .find("option:selected")
        .text();

    p1male === "男" ? (p1male = 0) : (p1male = 1);
    var p1company = $("#editp1company").val();
    var p1relationship = $("#editp1relationship").val();
    var p2name = $("#editp2name").val();
    var p2male = $("#editp2male")
        .find("option:selected")
        .text();
    p2male === "男" ? (p2male = 0) : (p2male = 1);
    var p2company = $("#editp2company").val();
    var p2relationship = $("#editp2relationship").val();
    var role = $("#editrole")
        .find("option:selected")
        .text();
    role = role==="在职"?1:0;

    Ajax.post(
        {
          url: `staff/editstaff`,
          data: {
            staffid: staffid,
            username: username,
            male: Number(male),
            birthday: birthday,
            nation: nation,
            party: party,
            healthy: healthy,
            nativeplace: nativeplace,
            address: address,
            phone: phone,
            emergencyphone: emergencyphone,
            p1name: p1name,
            p1male: Number(p1male),
            p1company: p1company,
            p1relationship: p1relationship,
            p2name: p2name,
            p2male: Number(p2male),
            p2company: p2company,
            p2relationship: p2relationship,
            employment: role,
            editpassword: passwd,
            growth: growth
          }
        },
        res => {
          if (res.code === 0) {
            alert("修改成功");
            $("#changestaff").css("display","none");
            allStaff();
          }
        }
    );
  });

  //编辑时填充
  $(document).on("click",".editstaff",function (e) {

    // $("#editusername").attr("disabled","disabled");
    var staffid = $(this).data("staffid");
    sessionStorage.setItem("staffid",staffid);
    Ajax.get(
        {
          url: `staff/getonestaff`,
          data:{id:staffid}
        },
        res => {
          if (res["msg"] === "成功") {
            var data = res.data;
            $("#editusername").val(data["name"]);
            $("#editmale").find("option:selected").text(data["male"]===0?"男":"女");
            $("#test-e6").text(data["birthday"]);
            $("#editrole").find("option:selected").text(data["role"]===1?"在职":"离职");
            $("#editnation").find("option:selected").text(data["nation"]);
            $("#editparty").find("opeion:selected").text(data["party"]);
            $("#edithealthy").find("option:selected").text(data["healthy"]);
            $("#editnativeplace").val(data["nativeplace"]);
            $("#editaddress").val(data["address"]);
            $("#editphone").val(data["phone"]);
            $("#editemergencyphone").val(data["emergencyphone"]);
            $("#editp1name").val(data["p1name"]==="无"?"":data["p1name"]);
            $("#editp1male").val(data["p1male"]);
            $("#editp1company").val(data["p1company"]==="无"?"":data["p1company"]);
            $("#editp1relationship").val(data["p1relationship"]==="无"?"":data["p1relationship"]);
            $("#editp2name").val(data["p2name"]==="无"?"":data["p2name"]);
            $("#editp2male").val(data["p2male"]);
            $("#editgrowth").val(data["growth"]);
            $("#editp2company").val(data["p2company"]==="无"?"":data["p2company"]);
            $("#editp2relationship").val(data["p2relationship"]==="无"?"":data["p2relationship"]);
          }
        }
    );
  });


  //获取所有staff
  $("#addentry").click(function () {
    Ajax.get(
        {
          url: `staff/allstaff`
        },
        res => {
          var reporterlist=$("#reporter");

          console.log(res)
          if (res["code"] == 0) {

            $.each(res["data"], function (index, item) {
              reporterlist.append(`<option value="${item.id}">${item.name}</option>`)
            });

          } else {
            alert(res["msg"]);
          }
        }
    );
  });

  $("#addreporterbtn").click(function () {
    var staffid = $("#reporter")
        .find("option:selected")
        .val();

    Ajax.post(
        {
          url: `shop/reporter/add`,
          data: {
            staffid: staffid
          }
        },
        res => {
          if (res.code == 0) {
            alert("添加成功");
            $("#entryclerk").css("display", 'none');
          } else {
            alert(res.msg);
          }
          allStaff()
        }
    );
  });

  // 添加staff
  $(".addstaff").click(function() {
    var username = $("#staffusername").val();
    var growth = $("#growth").val();

    var passwd = $("#passwd").val();
    var repeatpasswd = $("#repeatpasswd").val();

    var male = $("#male")
      .find("option:selected")
      .text();

    male === "男" ? (male = 0) : (male = 1);
    var birthday = $("#test-d4").text();
    var nation = $("#nation").val();
    var party = $("#party")
      .find("option:selected")
      .text();
    var healthy = $("#healthy")
      .find("option:selected")
      .text();
    var nativeplace = $("#nativeplace").val();
    var address = $("#address").val();
    var phone = $("#phone").val();
    var emergencyphone = $("#emergencyphone").val();
    var p1name = $("#p1name").val();
    var p1male = $("#p1male")
      .find("option:selected")
      .text();

    p1male === "男" ? (p1male = 0) : (p1male = 1);
    var p1company = $("#p1company").val();
    var p1relationship = $("#p1relationship").val();
    var p2name = $("#p2name").val();
    var p2male = $("#p2male")
      .find("option:selected")
      .text();
    p2male === "男" ? (p2male = 0) : (p2male = 1);
    var p2company = $("#p2company").val();
    var p2relationship = $("#p2relationship").val();
    var role = $("#role")
      .find("option:selected")
      .text();
    role = role==="在职"?1:0;

    if(passwd!=repeatpasswd){
      alert("密码不一致");
      return 0;
    }

    Ajax.post(
      {
        url: `staff/addstaff`,
        data: {
          username: username,
          password: passwd,
          male: Number(male),
          birthday: birthday,
          nation: nation,
          party: party,
          healthy: healthy,
          nativeplace: nativeplace,
          address: address,
          phone: phone,
          emergencyphone: emergencyphone,
          p1name: p1name,
          p1male: Number(p1male),
          p1company: p1company,
          p1relationship: p1relationship,
          p2name: p2name,
          p2male: Number(p2male),
          p2company: p2company,
          p2relationship: p2relationship,
          employment: role,
          growth: growth
        }
      },
      res => {
        if (res["msg"] === "创建成功") {
          allStaff();
          $("#dangan").css("display", "none");

          $("#staffusername").val("");
          $("#passwd").val("");
          $("#repeatpasswd").val("");
          // $("#male")
          //     .find("option:selected")
          //     .text("请选择");
          // $("#test-d4").text("");
          $("#nation").val("");
          $("#nativeplace").val("");
          $("#address").val("");
          $("#phone").val("");
          $("#emergencyphone").val("");
          $("#p1name").val("");
          $("#p1company").val("");
          $("#p1relationship").val("");
          $("#p2name").val("");
          $("#p2company").val("");
          $("#p2relationship").val("");
          $("#growth").val("");
          var stffinfor = [
            {
              username: username,
              male: male,
              birthday: birthday,
              nation: nation,
              party: party,
              healthy: healthy,
              nativeplace: nativeplace,
              address: address,
              phone: phone,
              emergencyphone: emergencyphone,
              p1name: p1name,
              p1male: p1male,
              p1company: p1company,
              p1relationship: p1relationship,
              p2name: p2name,
              p2male: p2male,
              p2company: p2company,
              p2relationship: p2relationship,
              employment: role,
              growth: growth

            }
          ];
          var ul = $("#tab-5-1 > div.information > div > ul");
          $.each(stffinfor, function(index, item) {
            var li = $("<li></li>");

            li.html(
              `<span class="name">${item.name}</span>
              <span class="sex">${
                male === 0 ? "男" : "女"
              }</span><span class="month"><span class="dateInput" type="text" id="test-n7">${
                item.birthday
              }</span></span><span class="minzu">${
                item.nation
              }</span><span class="zhiwei">${
                item.role
              }</span><span class="zhengzhi">${
                item.party
              }</span><span class="shenti">${
                item.healthy
              }</span><span class="jiguan">${
                item.nativeplace
              }</span><span class="add">${
                item.address
              }</span><span class="tel">${item.phone}</span><span class="tel">${
                item.emergencyphone
              }</span><span><button class="editstaff">编辑</button><button class="btnstaff del">删除</button></span>`
            );

            $(ul).append(li);
          });
          // console.log(ul);
          $(".stafflist").empty();
          $(".stafflist").append(ul);
        } else {
          alert(res["msg"]);
        }
      }
    );
  });
  // 运营概况数量
  Ajax.get(
    {
      url: `shop/status/shop`
    },
    res => {
      if (res["msg"] === "成功") {
        $(".gailan>.gailanbox>.brandnum>span").text(res.data.customercount);
        $(".gailan>.gailanbox>.shopnum>span").text(res.data.staffcount);
      }
    }
  );
  // 修改staff
  // $(".suredit").click(function() {
  //   console.log(111);
  // });
});
