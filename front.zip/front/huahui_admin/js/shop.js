$(document).ready(function () {
    // 列出所有shop
    function allShop(page) {
        Ajax.get(
            {
                url: `shop/allshop`,
                data:{pagenum:page}
            },
            res => {
                $('#shoppageTool').empty()
                $(".shoplist").empty()
                let head=`
                           <div class="top">
                                <span class="shop">商家名</span>
                                <span class="des">负责人</span>
                                <span class="pic">位置</span>
                                <span class="do">操作</span>
                            </div>
                `
                if (res["msg"] === "成功") {
                    var ul = $("<ul>");
                    // var data = res["data"];
                    // allshop = data;
                    $(".shoplist ul").empty();
                    $.each(res.data, function (index, item) {
                        var li = $(`<li data-shopid="${item.shopid}"></li>`);
                        li.html(
                            `<p class="clickShopName" data-shopid="${item.shopid}" style="cursor: pointer;text-decoration: underline;font-weight: bold">${item.shopname}</p><span>${item.controller}</span><span>${item.geo}</span><button data-shopid="${item.shopid}" class="editshop">编辑</button><button data-shopid="${item.shopid}" class="del delshop">删除</button>`
                        );
                        ul.append(li);
                    });
                    $(".shoplist").append(head);
                    $(".shoplist").append(ul);
                    var p = new Paging();
                    p.init({
                        target: '#shoppageTool',
                        pagesize: res["pageinfo"]["pagessize"],
                        count: res["pageinfo"]["count"],
                        current: res["pageinfo"]["current"],
                        callback:function (pagecount) {
                            allShop(pagecount)
                        }
                    });
                }
            }
        );
    }

    allShop();

    //进入shop权限
    $(document).on("click", "p.clickShopName", function (e) {
        e.stopPropagation();
        var shopid = $(this).data("shopid");
        Ajax.get(
            {
                url: `brand/toshop`,
                data:{
                    shopid:shopid
                }
            },
            res => {
                if (res.code===0) {
                    sessionStorage.setItem("change",res.msg);
                    window.location.href = "./shop.html";
                }
            }
        );
    });



    //确认删除
    $(document).on("click", ".delshop", function (e) {
        e.stopPropagation();
        var userid = $(this).data("shopid");
        var operat = confirm("确定删除吗？");
        if (operat == true) {
            console.log("你点击了确定");
            Ajax.post(
                {
                    url: `shop/deleteshop`,
                    data: {
                        shopid: userid
                    }
                },
                res => {
                    if (res.msg === "删除成功") {
                        allShop();
                    } else {
                        alert("删除失败，请稍后重试。");
                    }
                }
            );
        } else {
            console.log("你点击了取消");
        }
    });

    //   添加shop
    $("#addshop .addshop").click(function () {
        var username = $("#shopusername").val();
        var password = $("#shoppssword").val();
        var controller = $("#controller").val();
        var phoneOrWechat = $("#phoneOrWechat").val();
        var mianji = $("#mianji").val();
        var mainproject = $("#mainProject").val();
        var rooms = $("#rooms").val();
        var rent = $("#rent").val();
        var beds = $("#beds").val();
        var single = $("#single").val();
        var repeatpassword = $("#shoprepeatword").val();

        var province = $("#province")
            .find("option:selected")
            .text();
        var city = $(".city")
            .find("option:selected")
            .text();
        var district = $(".district")
            .find("option:selected")
            .text();
        var geo = $("#shopgeo").val();
        if (12 < password.length || repeatpassword.length < 6) {
            alert("密码不能大于12位数并且不能少于6位数");
            return false;
        }
        Ajax.post(
            {
                url: `shop/addshop`,
                data: {
                    username: username,
                    password: password,
                    repeatpassword: repeatpassword,
                    controller: controller,
                    phoneOrWechat : phoneOrWechat,
                    mianji : mianji,
                    mainproject:mainproject,
                    rooms:rooms,
                    rent:rent,
                    beds:beds,
                    single:single,
                    province: province,
                    city: city,
                    district: district,
                    geo: geo
                }
            },
            res => {
                if (res["code"] === 0) {
                    $("#addshop").css("display", "none");
                    $("#shopusername").val("");
                    $("#shoppssword").val("");
                    $("#controller").val("");
                    $("#phoneOrWechat").val("");
                    $("#mianji").val("");
                    $("#mainProject").val("");
                    $("#rooms").val("");
                    $("#rent").val("");
                    $("#beds").val("");
                    $("#single").val("");
                    $("#shoprepeatword").val("");
                    $("#shopgeo").val("");
                    allShop();
                } else {
                    alert(res["msg"]);
                }
            }
        );
    });

    //显示shop detail
    $(document).on("click", "#tab-1 > div > div.list.shoplist > ul:nth-child(3) > li", function (e) {
        var shopid = $(this).data("shopid");
        Ajax.get(
            {
                url: `shop/oneshop`,
                data:{
                    shopid:shopid
                }
            },
            res => {
                if (res.code===0) {
                    data = res["data"];
                    var tbody = $("#shopdetailContent");
                    tbody.empty();
                    tbody.append(`<tr style="text-align: center;">
                    <td>${data.name}</td>
                    <td>${data.phoneOrWechat}</td>
                    <td>${data.mianji}</td>
                    <td>${data.mainProject}</td>
                    <td>${data.rent}</td>
                    <td>${data.beds}</td>
                    <td>${data.single}</td>
                    <td>${data.rooms}</td>
                </tr>`);
                    $("#shopdetail").css("display","block");
                }
            }
        );

    });


    //修改get  shop
    $(document).on("click", ".editshop", function (e) {
        e.stopPropagation();
        var shopid = $(this).data("shopid");
        Ajax.get(
            {
                url: `shop/oneshop`,
                data:{
                    shopid:shopid
                }
            },
            res => {
                if (res.code===0) {
                    var data = res["data"];
                    $("#editshopusername").val(data.name);
                    $("#editcontroller").val(data.controller);
                    $("#editphoneOrWechat").val(data.phoneOrWechat);
                    $("#editmianji").val(data.mianji);
                    $("#editmainProject").val(data.mainProject);
                    $("#editrooms").val(data.rooms);
                    $("#editrent").val(data.rent);
                    $("#editbeds").val(data.beds);
                    $("#editsingle").val(data.single);
                    $("#editprovince")
                        .find("option:selected")
                        .text(data.province);
                    $("#editcitys")
                        .find("option:selected")
                        .text(data.city);
                    $("#editcounty").find("option:selected")
                        .text(data.district);
                    $("#editshopgeo").val(data.geo);

                }
            }
        );
    });


    //post修改shop
    $("#changeshop .addshop").click(function () {
        var shopid = sessionStorage.getItem("shopid");
        var controller = $("#editcontroller").val();
        var phoneOrWechat = $("#editphoneOrWechat").val();
        var mianji = $("#editmianji").val();
        var mainproject = $("#editmainProject").val();
        var rooms = $("#editrooms").val();
        var rent = $("#editrent").val();
        var beds = $("#editbeds").val();
        var single = $("#editsingle").val();
        var province = $("#editprovince")
            .find("option:selected")
            .text();
        var city = $("#editcitys")
            .find("option:selected")
            .text();
        var district = $("#editcounty").find("option:selected")
            .text();
        var geo = $("#editshopgeo").val();
        Ajax.post(
            {
                url: `shop/editshop`,
                data: {
                    shopid: shopid,
                    province: province,
                    city: city,
                    district: district,
                    geo: geo,
                    controller:controller,
                    phoneOrWechat:phoneOrWechat,
                    mianji :mianji,
                    mainproject:mainproject,
                    rooms:rooms,
                    rent :rent,
                    beds :beds,
                    single :single
                }
            },
            res => {
                if (res["code"] === 0) {
                    $("#changeshop").css("display", "none");
                    $("#editcontroller").val("");
                    $("#editphoneOrWechat").val("");
                    $("#editmianji").val("");
                    $("#editmainProject").val("");
                    $("#editrooms").val("");
                    $("#editrent").val("");
                    $("#editbeds").val("");
                    $("#editsingle").val("");
                    // var shopinfor = [
                    //   {
                    //     username: username,
                    //     description: description
                    //   }
                    // ];
                    // $.each(shopinfor, function(index, item) {
                    allShop();
                    // var li = $("<li>").html(
                    //     `<span>${description}</span><span>${province}${city}${district}${geo}</span><button class="editshop">编辑</button><button class="del delshop">删除</button>`
                    // );
                    // $("#adbrand").append(li);
                    alert(res["msg"]);


                    // });
                } else {
                    alert(res["msg"]);
                }
            }
        );

    });





    // 获取修改员工信息
    // $("#addbuss").click(function() {
    //   $("#addshop").css("display", "block");
    //   Ajax.post({
    //     url: `shop/editshop`,
    //     data: {}
    //   });
    // });
    // 添加具体项目
    // $("#sureaddpro").click(function() {
    //   var projecetname = $("#projecetname").val();
    //   Ajax.post(
    //     {
    //       url: `brand/addproject`,
    //       data: {
    //         category2id: "123",
    //         projecetname: projecetname
    //       }
    //     },
    //     res => {
    //       if (res["code"] === 0) {
    //         var ul = $("<ul>");
    //         $("#project").css("display", "none");
    //         var data = [
    //           {
    //             projecetname: projecetname
    //           }
    //         ];
    //         $.each(data, function(index, item) {
    //           var li = $("<li>").html(
    //             `<span>${item.projecetname}</span><button class="del delproject">删除</button>`
    //           );
    //           ul.append(li);
    //         });
    //         $(".projectlist").append(ul);
    //       } else {
    //         alert(res.msg);
    //       }
    //     }
    //   );
    // });

    // // 删除项目
    // $(document).on("click", ".delproject", function(e) {
    //   $("#isdel").css("display", "block");
    //   $("#isdel").data("shopid", $(this).data("shopid"));
    // });
    // 运营概况数量
    Ajax.get(
        {
            url: `status/brand`
        },
        res => {
            if (res["msg"] === "成功") {
                $(".gailan>.gailanbox>.brandnum>span").text(res.data.shopcount);
                $(".gailan>.gailanbox>.shopnum>span").text(res.data.staffcount);
            }
        }
    );
});
