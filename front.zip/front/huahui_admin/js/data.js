var year = new Date().getFullYear();
var day = new Date().getDate();
var month = new Date().getMonth()+1;
var hour = new Date().getHours();
var minute = new Date().getMinutes();

// console.log(year + " " + day + " " + month);

laydate.render({
  elem: "#test-n1", //渲染的标签id名
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-n1")==null?
      year +
      "-" +
      (month < 10 ? "0" + month : month) +
      "-" +
      (day < 10 ? "0" + day : day):sessionStorage.getItem("#test-n1"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-n1",value)
  }
});
laydate.render({
  elem: "#test-n2", //渲染的标签id名
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-n2")==null?
      year +
      "-" +
      (month < 10 ? "0" + month : month) +
      "-" +
      (day < 10 ? "0" + day : day) :sessionStorage.getItem("#test-n2"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-n2",value)
  }
});
laydate.render({
  elem: "#test14",
  type: "time",
  format: "H:M",
  value: hour + ":" + minute
});
laydate.render({
  elem: "#test-n5", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-n5")==null?
      year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-n5"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-n5",value)
  }
});
laydate.render({
  elem: "#test-n6", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-n6")==null?
      year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-n6"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-n6",value)
  }
});
laydate.render({
  elem: "#test-n9", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-n9")==null?
      year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-n9"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-n9",value)
  }
});
laydate.render({
  elem: "#test-n8", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-n8")==null?
      year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-n8"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-n8",value)
  }
});
laydate.render({
  elem: "#test-d1", //渲染的标签id名
  format: "yyyy-MM-dd",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d1")==null?
      year +
      "-" +
      (month < 10 ? "0" + month : month) +
      "-" +
      (day < 10 ? "0" + day : day) :sessionStorage.getItem("#test-d1"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d1",value)
  }
});
laydate.render({
  elem: "#test-d2", //渲染的标签id名
  format: "yyyy-MM-dd",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d2")==null?
      year +
      "-" +
      (month < 10 ? "0" + month : month) +
      "-" +
      (day < 10 ? "0" + day : day) :sessionStorage.getItem("#test-d2"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d2",value)
  }
});
laydate.render({
  elem: "#test-d3", //渲染的标签id名
  format: "yyyy-MM-dd",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d3")==null?
      year +
      "-" +
      (month < 10 ? "0" + month : month) +
      "-" +
      (day < 10 ? "0" + day : day) :sessionStorage.getItem("#test-d3"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d3",value)
  }
});
laydate.render({
  elem: "#test-d4", //渲染的标签id名
  format: "yyyy-MM-dd",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d4")==null?
      year +
      "-" +
      (month < 10 ? "0" + month : month) +
      "-" +
      (day < 10 ? "0" + day : day):sessionStorage.getItem("#test-d4"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d4",value)
  }
});
laydate.render({
  elem: "#test-d5", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d5")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-d5"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d5",value)
  }
});
laydate.render({
  elem: "#test-d6", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d6")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-d6"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d6",value)
  }
});
laydate.render({
  elem: "#test-d7", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d7")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-d7"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d7",value)
  }
});
laydate.render({
  elem: "#test-d8", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d8")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-d8"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d8",value)
  }
});
laydate.render({
  elem: "#test-d9", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d9")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-d9"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d9",value)
  }
});
laydate.render({
  elem: "#test-d10", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-d10")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-d10"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-d10",value)
  }
});
laydate.render({
  elem: "#test-e1", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e1")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e1"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e1",value)
  }
});
laydate.render({
  elem: "#test-e2", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e2")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e2"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e2",value)
  }
});
laydate.render({
  elem: "#test-e3", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e3")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e3"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e3",value)
  }
});
laydate.render({
  elem: "#test-e4", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e4")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e4"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e4",value)
  }
});
laydate.render({
  elem: "#test-e5", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e5")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e5"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e5",value)
  }
});
laydate.render({
  elem: "#test-e6", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e6")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e6"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e6",value)
  }
});
laydate.render({
  elem: "#test-e7", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e7")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e7"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e7",value)
  }
});
laydate.render({
  elem: "#test-e8", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e8")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e8"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e8",value)
  }
});
laydate.render({
  elem: "#test-e9", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e9")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e9"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e9",value)
  }
});
laydate.render({
  elem: "#test-e0", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e0")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e0"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e0",value)
  }
});
laydate.render({
  elem: "#test-e11", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e11")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e11"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e11",value)
  }
});
laydate.render({
  elem: "#test-e12", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e12")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e12"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e12",value)
  }
});
laydate.render({
  elem: "#test-e13", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e13")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e13"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e13",value)
  }
});
laydate.render({
  elem: "#test-e14", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e14")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e14"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e14",value)
  }
});
laydate.render({
  elem: "#test-e15", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e15")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e15"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e15",value)
  }
});
laydate.render({
  elem: "#test-e16", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e16")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e16"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e16",value)
  }
});
laydate.render({
  elem: "#test-e17", //渲染的标签id名
  format: "yyyy年MM月dd日",
  showBottom: false,
  // theme: "#3ce4a9",
  value:sessionStorage.getItem("#test-e17")==null?
year +
      "年" +
      (month < 10 ? "0" + month : month) +
      "月" +
      (day < 10 ? "0" + day : day) +
      "日" :sessionStorage.getItem("#test-e17"),
  done:function(value, date, endDate) {
    sessionStorage.setItem("#test-e17",value)
  }
});
