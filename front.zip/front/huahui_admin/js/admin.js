$(document).ready(function () {
  /*修改密码*/
  $("#change").click(function () {
    var passwd = $("#newword").val();
    var repeatpasswd = $("#sureword").val();
    if (passwd !== repeatpasswd) {
      alert("请输入两次相同密码");
      return false;
    }
    if (12 < passwd.length || repeatpasswd.length < 6) {
      alert("密码不能大于12位数并且不能少于6位数");
      return false;
    }
    Ajax.post({
      url: `user/changepssword`,
      data: {
        passwd: passwd,
        repeatpasswd: repeatpasswd
      }
    }, res => {
      console.log(res);
      alert(res["msg"]);
    });
  });
  /*退出登录*/
  $("#logout").click(function () {
    Ajax.post({
      url: `logout`
    }, res => {
      console.log(res);
      sessionStorage.removeItem("change");
      window.location.href = "../index.html";
    });
  });

  //获取网站标题
  Ajax.get(
      {
        url: `setting/wxfirst`
      },
      res => {
        console.log(res)
        if (res["code"] == 0) {
          $(".wxfirst").val(res["data"]["name"]);
        } else {
        }
      }
  );
});


