package com.aaa.huahui.model;

public class Reporter {
}
