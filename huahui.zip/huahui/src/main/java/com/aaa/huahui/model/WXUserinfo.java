package com.aaa.huahui.model;

import com.alibaba.fastjson.JSONArray;

public class WXUserinfo {
    String openid;
    String nickname;
    int sex;
    String language;
    String city;
    String province;
    String country;
    String headimgurl;

    public JSONArray getPrivilege() {
        return privilege;
    }

    public void setPrivilege(JSONArray privilege) {
        this.privilege = privilege;
    }

    JSONArray privilege;


    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHeadimgurl() {
        return headimgurl;
    }

    public void setHeadimgurl(String headimgurl) {
        this.headimgurl = headimgurl;
    }

    public WXUserinfo() {
    }
}
