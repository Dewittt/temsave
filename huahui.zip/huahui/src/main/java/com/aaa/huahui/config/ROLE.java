package com.aaa.huahui.config;

public class ROLE {
    /**
     * 管理员
     **/
    public static final String ADMIN = "ROLE_ADMIN";

    /**
     * 品牌
     **/
    public static final String BRAND = "ROLE_BRAND";

    /**
     * 分店店长
     **/
    public static final String SHOP = "ROLE_SHOP";

    /**
     * 店员
     **/
    public static final String STAFF = "ROLE_STAFF";

    /**
     * 录入员
     **/
    public static final String REPORTER = "ROLE_REPORTER";

}
